'use strict';
/*
  totp.js: TOTP (RFC 6238) sobre HOTP (RFC 4226), com HMAC-SHA1, 6 dígitos e
  passo de 30 s. Só o módulo `crypto` do Node; o base32 (RFC 4648, sem padding)
  é próprio. São exatamente os parâmetros que os aplicativos autenticadores
  (Google Authenticator e parecidos) assumem: mudar qualquer um deles faz o
  celular gerar códigos que o agente nunca aceita.

  Aqui só mora a matemática (sem disco e sem relógio global): quem guarda o
  segredo e o último contador aceito é o acesso.js. As funções recebem o
  relógio como argumento (agoraMs), para o teste fixar o tempo.
*/
const crypto = require('crypto');

const ALFABETO = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
const PASSO_S = 30;
const JANELA = 1; // aceita o passo atual, o anterior e o seguinte (relógios com até ~30 s de diferença)
const DIGITOS_RE = /^[0-9]{6}$/;
const EMISSOR = 'Lab Desktop';

function base32Codificar(buf) {
  let bits = 0;
  let valor = 0;
  let saida = '';
  for (const byte of buf) {
    valor = (valor << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      saida += ALFABETO.charAt((valor >>> (bits - 5)) & 31);
      bits -= 5;
    }
    valor &= (1 << bits) - 1; // descarta o que já saiu: o int32 do JS não estoura
  }
  if (bits > 0) saida += ALFABETO.charAt((valor << (5 - bits)) & 31);
  return saida;
}

// Aceita minúsculas, espaços, hífens e '=' (o autenticador mostra a chave em
// grupos); devolve null se houver caractere fora do alfabeto.
function base32Decodificar(txt) {
  const limpo = String(txt).replace(/[\s=-]/g, '').toUpperCase();
  let bits = 0;
  let valor = 0;
  const bytes = [];
  for (const c of limpo) {
    const v = ALFABETO.indexOf(c);
    if (v < 0) return null;
    valor = (valor << 5) | v;
    bits += 5;
    if (bits >= 8) {
      bytes.push((valor >>> (bits - 8)) & 255);
      bits -= 8;
      valor &= (1 << bits) - 1;
    }
  }
  return Buffer.from(bytes);
}

function novoSegredo() {
  return crypto.randomBytes(20); // 160 bits = 32 caracteres base32, sem padding
}

// HOTP: contador inteiro entre 0 e 2^53, devolve 6 dígitos como texto.
function hotp(segredo, contador) {
  if (typeof contador !== 'number' || contador < 0 || contador !== Math.floor(contador) || contador > Number.MAX_SAFE_INTEGER) {
    throw new RangeError('contador HOTP inválido');
  }
  const msg = Buffer.alloc(8);
  msg.writeUInt32BE(Math.floor(contador / 4294967296), 0);
  msg.writeUInt32BE(contador % 4294967296, 4);
  const h = crypto.createHmac('sha1', segredo).update(msg).digest();
  const o = h[19] & 15; // truncamento dinâmico (RFC 4226, 5.3)
  const n = ((h[o] & 127) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3];
  return String(n % 1000000).padStart(6, '0');
}

function contadorEm(agoraMs) {
  return Math.floor(agoraMs / 1000 / PASSO_S);
}

// O código que o autenticador mostraria neste instante (usado pelos testes).
function codigo(segredo, agoraMs) {
  return hotp(segredo, contadorEm(agoraMs));
}

// Devolve o contador aceito, ou null. Anti-replay: só vale contador MAIOR que o
// último aceito (guardado por quem chamou), senão um código espiado valeria de
// novo durante a janela de ~90 s. Compara os 3 passos sem parada antecipada e em
// tempo constante, para o tempo de resposta não dizer qual dos três casou.
function verificar(segredo, codigoDigitado, agoraMs, ultimoContador) {
  if (!DIGITOS_RE.test(String(codigoDigitado))) return null;
  const atual = contadorEm(agoraMs);
  const recebido = Buffer.from(String(codigoDigitado));
  let achado = null;
  for (let c = atual - JANELA; c <= atual + JANELA; c++) {
    if (c < 0) continue;
    const casou = crypto.timingSafeEqual(Buffer.from(hotp(segredo, c)), recebido);
    const novo = ultimoContador === null || ultimoContador === undefined || c > ultimoContador;
    if (casou && novo && achado === null) achado = c;
  }
  return achado;
}

// otpauth://totp/Lab%20Desktop:<servidor>?secret=<base32>&issuer=Lab%20Desktop
// O emissor aparece duas vezes (no rótulo e no parâmetro) porque alguns
// autenticadores só leem um dos dois.
function uri(segredoBase32, servidor) {
  const emissor = encodeURIComponent(EMISSOR);
  return 'otpauth://totp/' + emissor + ':' + encodeURIComponent(servidor) + '?secret=' + segredoBase32 + '&issuer=' + emissor;
}

module.exports = {
  base32Codificar,
  base32Decodificar,
  novoSegredo,
  hotp,
  contadorEm,
  codigo,
  verificar,
  uri,
  PASSO_S,
  JANELA,
  EMISSOR
};
