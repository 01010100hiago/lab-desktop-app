#!/usr/bin/env node
'use strict';
/*
  Agente de monitoramento do Lab Desktop.

  Um servidor HTTP pequeno que mostra a saúde de UMA máquina (CPU, memória, disco, rede,
  temperatura, processos, Docker) ao aplicativo Lab Desktop. É SÓ LEITURA: não cria, não
  altera e não apaga nada na máquina, e não executa comando nenhum.

  Rotas (e só elas; o resto responde 404):
    GET  /api/versao             teste de saúde e compatibilidade
    GET  /api/servidor           métricas, histórico de 10 min e processos
    GET  /api/servidor/detalhe   o mesmo mais sensores, energia e máquina
    GET  /api/servidor/historico?janela=10m|1h|1d|7d|30d
    POST /api/acesso/2fa         confirma o código do autenticador (única rota que escreve, e só no
                                 estado de acesso do próprio agente)

  Segurança por padrão (ver SECURITY.md e README.md):
    - escuta só em 127.0.0.1 (PAINEL_ESCUTA=todas é só para container com a porta publicada em loopback);
    - TODA chamada exige token; não existe modo sem token; quem erra o token é limitado, quem acerta nunca é bloqueado;
    - recusa Host que não seja localhost/127.0.0.1/[::1] (DNS rebinding) e qualquer Origin de outro lugar;
    - o Docker só é lido, pelo filtro de docker-proxy.js;
    - sai de root na partida (privilegios.js).
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const acesso = require('./acesso.js');
const historicoMetricas = require('./historico.js');
const dockerProxy = require('./docker-proxy.js');
const { criarMetricas } = require('./metricas.js');
const { reduzirPrivilegios } = require('./privilegios.js');

const PERFIL = 'monitor';
// O que este agente sabe fazer, no formato que o app lê em /api/versao.
const RECURSOS = Object.freeze({ claude: false, projetos: false, monitor: true, guia_ia: false, historico: true });
const LIMITE_CORPO = 2048;
const LIMITE_URL = 2048;
// Limites HTTP contra conexão que se arrasta (slowloris). O Node só confere os prazos a cada `connectionsCheckingInterval`
// (padrão 30 s), então ele também é curto.
const LIMITES_HTTP = Object.freeze({
  headersTimeout: 5000, requestTimeout: 10000, keepAliveTimeout: 5000, connectionsCheckingInterval: 1000,
  maxConnections: 128, conexoesPorEndereco: 32, maxHeaderSize: 8192, maxHeadersCount: 50
});
const HOST_RE = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;

class ErroDeConfiguracao extends Error {}

/*
  Lê e valida o ambiente. Valor desconhecido NUNCA cai num padrão mais aberto: erro de digitação
  não pode expor o agente.
*/
function lerConfiguracao(env = process.env) {
  const texto = (nome, padrao) => (env[nome] === undefined || String(env[nome]).trim() === '' ? padrao : String(env[nome]).trim());
  const perfil = texto('PAINEL_PERFIL', PERFIL);
  if (perfil !== PERFIL) throw new ErroDeConfiguracao('PAINEL_PERFIL inválido: "' + perfil.slice(0, 40) + '" (este agente só tem o perfil "monitor").');
  if (env.PAINEL_EXIGE_TOKEN !== undefined && /^(0|false|nao|não|no|off)$/i.test(String(env.PAINEL_EXIGE_TOKEN).trim())) {
    throw new ErroDeConfiguracao('O token é obrigatório e não pode ser desligado (PAINEL_EXIGE_TOKEN=0 não existe).');
  }
  const porta = Number(texto('PORT', '7000'));
  if (!Number.isInteger(porta) || porta < 1 || porta > 65535) throw new ErroDeConfiguracao('PORT inválida: use um número de 1 a 65535.');
  const escuta = texto('PAINEL_ESCUTA', 'loopback');
  if (escuta !== 'loopback' && escuta !== 'todas') throw new ErroDeConfiguracao('PAINEL_ESCUTA inválido: "' + escuta.slice(0, 40) + '" (use "loopback" ou "todas").');
  const hostsExtra = texto('PAINEL_HOSTS_EXTRA', '').split(',').map((h) => h.trim().toLowerCase()).filter(Boolean);
  for (const h of hostsExtra) {
    if (!HOST_RE.test(h)) throw new ErroDeConfiguracao('PAINEL_HOSTS_EXTRA inválido: só nomes de máquina, separados por vírgula.');
  }
  return {
    porta,
    escuta,
    enderecoDeEscuta: escuta === 'todas' ? '0.0.0.0' : '127.0.0.1',
    hostsPermitidos: ['localhost', '127.0.0.1', '[::1]', ...hostsExtra],
    dadosDir: texto('PAINEL_DADOS_DIR', '/srv/painel/dados'),
    dockerSocket: texto('PAINEL_DOCKER_SOCKET', dockerProxy.SOCKET_PADRAO),
    hostDir: texto('PAINEL_HOST_DIR', '/host'),
    versaoArquivo: texto('PAINEL_VERSAO_ARQUIVO', path.join(__dirname, 'VERSAO'))
  };
}

function lerVersaoDoPacote(arquivo) {
  try {
    const v = fs.readFileSync(arquivo, 'utf8').trim();
    return /^[A-Za-z0-9._+-]{1,64}$/.test(v) ? v : null;
  } catch (e) {
    return null;
  }
}

function nomeDoHost(cabecalho) {
  const h = String(cabecalho || '').toLowerCase();
  return h.charAt(0) === '[' ? h.slice(0, h.indexOf(']') + 1) : h.split(':')[0];
}

/*
  Monta o servidor (sem ouvir). Tudo que toca fora do processo entra por `opcoes`, para os testes
  usarem pastas e um Docker de mentira.
*/
function criarServidor(opcoes) {
  const cfg = opcoes.configuracao;
  fs.mkdirSync(cfg.dadosDir, { recursive: true, mode: 0o700 });
  const gravador = historicoMetricas.criar({ arquivo: path.join(cfg.dadosDir, 'serie-historica.json'), relogio: opcoes.relogio });
  gravador.carregar();
  const docker = opcoes.docker || dockerProxy.criarCliente({ socket: cfg.dockerSocket });
  const metricas = criarMetricas({
    docker, gravador, procDir: opcoes.procDir, sysDir: opcoes.sysDir, hostDir: opcoes.hostDir || cfg.hostDir, relogio: opcoes.relogio
  });
  acesso.init({ tokens: path.join(cfg.dadosDir, 'tokens-clientes.json'), totp: path.join(cfg.dadosDir, 'acesso-totp.json'), agora: opcoes.relogio });
  const limitador = opcoes.limitador || acesso.criarLimitador({ relogio: opcoes.relogio });
  const versaoDoPacote = lerVersaoDoPacote(cfg.versaoArquivo);
  const hostsOk = new Set(cfg.hostsPermitidos);

  function json(res, status, obj, cabecalhos) {
    const corpo = JSON.stringify(obj);
    res.writeHead(status, Object.assign({
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(corpo),
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Cross-Origin-Resource-Policy': 'same-origin'
    }, cabecalhos));
    res.end(corpo);
  }

  // corpo JSON de até LIMITE_CORPO bytes; só aceita objeto (`null`, número e lista chegavam aos tratadores e quebravam)
  function lerCorpo(req) {
    return new Promise((resolve, reject) => {
      const declarado = Number(req.headers['content-length']);
      if (Number.isFinite(declarado) && declarado > LIMITE_CORPO) return reject(new Error('grande'));
      const partes = [];
      let total = 0;
      req.on('data', (c) => {
        total += c.length;
        if (total > LIMITE_CORPO) {
          partes.length = 0;
          reject(new Error('grande'));
          return;
        }
        partes.push(c);
      });
      req.on('end', () => {
        try {
          const obj = JSON.parse(Buffer.concat(partes).toString('utf8') || '{}');
          if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return reject(new Error('invalido'));
          return resolve(obj);
        } catch (e) { return reject(new Error('invalido')); }
      });
      req.on('error', () => reject(new Error('erro')));
      return undefined;
    });
  }

  function origemPermitida(req) {
    const origem = req.headers.origin;
    if (origem !== undefined) {
      // só a própria origem de loopback; qualquer outro site (ou "null") é recusado
      let host;
      try { host = new URL(origem).host; } catch (e) { return false; }
      if (!hostsOk.has(nomeDoHost(host))) return false;
    }
    const site = req.headers['sec-fetch-site'];
    return site === undefined || site === 'same-origin' || site === 'none';
  }

  async function tratar(req, res) {
    // 1. Host: só o próprio computador. Mata o DNS rebinding (um site que aponta o próprio nome para 127.0.0.1).
    if (!hostsOk.has(nomeDoHost(req.headers['host']))) {
      res.writeHead(421, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end('Host não permitido.');
    }
    // 2. Origin: o app nativo não manda; um navegador manda. Só a própria origem passa.
    if (!origemPermitida(req)) return json(res, 403, { erro: 'Origem não permitida.' });

    // 3. Token. O 401 vem antes de qualquer decisão de rota: sem token ninguém descobre o que existe.
    const endereco = req.socket.remoteAddress || '?';
    const cred = acesso.avaliar(req);
    if (cred.tipo === 'negado') {
      if (cred.contaTentativa) {
        // 4. Limite de tentativas: só vale para quem NÃO trouxe um token válido. Quem traz o token certo nunca é bloqueado
        // (pelo túnel SSH todos os clientes parecem vir de 127.0.0.1; ninguém pode trancar quem tem o token).
        const espera = limitador.espera(endereco);
        if (espera > 0) {
          const s = Math.ceil(espera / 1000);
          return json(res, 429, { erro: 'Muitas tentativas. Aguarde ' + s + ' s.', codigo: 'muitas_tentativas', aguarde_s: s }, { 'Retry-After': String(s) });
        }
        if (limitador.registrarFalha(endereco)) console.log('[acesso] muitas recusas de credencial seguidas: recusando quem não tem token por um minuto');
      }
      return json(res, 401, cred.codigo ? { erro: cred.erro, codigo: cred.codigo } : { erro: 'Token ausente ou inválido.' });
    }

    // 5. A URL: só ASCII visível, de tamanho razoável.
    if (typeof req.url !== 'string' || req.url.length > LIMITE_URL || !/^\/[\x21-\x7e]*$/.test(req.url)) return json(res, 400, { erro: 'Pedido inválido.' });
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch (e) { return json(res, 400, { erro: 'Pedido inválido.' }); }
    const caminho = url.pathname;

    // 6. As rotas. A lista é fechada.
    if (req.method === 'GET' && caminho === '/api/versao') {
      return json(res, 200, {
        api: 1, painel: process.version, exigeToken: true, cliente: cred.nome, totp: acesso.totpPublico(),
        perfil: PERFIL, recursos: RECURSOS, agente: versaoDoPacote
      });
    }
    if (req.method === 'POST' && caminho === '/api/acesso/2fa') {
      let corpo;
      try { corpo = await lerCorpo(req); } catch (e) {
        return json(res, 400, { erro: 'Corpo inválido.' }, { Connection: 'close' });
      }
      const r = acesso.confirmar2fa(cred, corpo);
      return json(res, r.status, r.corpo, r.status === 429 ? { 'Retry-After': String(r.corpo.aguarde_s) } : undefined);
    }
    if (req.method === 'GET' && caminho === '/api/servidor') return json(res, 200, await metricas.infoServidor({ comProcessos: true, comHistorico: true }));
    if (req.method === 'GET' && caminho === '/api/servidor/detalhe') return json(res, 200, await metricas.detalhe());
    if (req.method === 'GET' && caminho === '/api/servidor/historico') {
      // Uma janela por chamada; ausente, repetida ou desconhecida é 400 com as válidas. A janela só é julgada DEPOIS do token.
      const pedidas = url.searchParams.getAll('janela');
      if (pedidas.length !== 1 || !historicoMetricas.janelaValida(pedidas[0])) {
        return json(res, 400, { erro: 'Informe uma janela: janela=10m, 1h, 1d, 7d ou 30d.', validas: Object.keys(historicoMetricas.JANELAS) });
      }
      return json(res, 200, gravador.consultar(pedidas[0]));
    }
    return json(res, 404, { erro: 'Esta rota não existe no perfil monitor do agente (só leitura do servidor).', perfil: PERFIL });
  }

  const L = Object.assign({}, LIMITES_HTTP, opcoes.limitesHttp);
  const servidor = http.createServer({ maxHeaderSize: L.maxHeaderSize, connectionsCheckingInterval: L.connectionsCheckingInterval }, (req, res) => {
    tratar(req, res).catch(() => {
      // nada do erro (nem caminho, nem pilha) vai para quem chamou
      console.error('[painel] erro ao tratar um pedido');
      if (!res.headersSent) json(res, 500, { erro: 'Erro interno.' });
      else res.destroy();
    });
  });
  servidor.headersTimeout = L.headersTimeout;
  servidor.requestTimeout = L.requestTimeout;
  servidor.keepAliveTimeout = L.keepAliveTimeout;
  servidor.maxHeadersCount = L.maxHeadersCount;
  servidor.maxConnections = L.maxConnections;
  // No máximo `conexoesPorEndereco` conexões abertas por endereço: um cliente (ou um laço) não segura todas as vagas.
  const abertas = new Map();
  servidor.on('connection', (socket) => {
    const a = socket.remoteAddress || '?';
    const n = (abertas.get(a) || 0) + 1;
    if (n > L.conexoesPorEndereco) return socket.destroy();
    abertas.set(a, n);
    return socket.once('close', () => {
      const restante = (abertas.get(a) || 1) - 1;
      if (restante <= 0) abertas.delete(a); else abertas.set(a, restante);
    });
  });
  // Este agente não usa WebSocket, túnel nem upgrade: derruba.
  servidor.on('upgrade', (req, socket) => socket.destroy());
  servidor.on('connect', (req, socket) => socket.destroy());
  servidor.on('clientError', (erro, socket) => {
    // pedido que nem chega a ser HTTP válido: resposta curta e fecha (cabeçalho grande demais é 431)
    if (!socket.writable) return socket.destroy();
    const status = erro && erro.code === 'HPE_HEADER_OVERFLOW' ? '431 Request Header Fields Too Large' : '400 Bad Request';
    return socket.end('HTTP/1.1 ' + status + '\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');
  });

  return {
    servidor,
    gravador,
    metricas,
    limitador,
    fechar() {
      metricas.parar();
      return new Promise((resolve) => {
        servidor.close(() => resolve());
        servidor.closeAllConnections();
      });
    }
  };
}

function iniciar() {
  let configuracao;
  try { configuracao = lerConfiguracao(process.env); } catch (e) {
    console.error('[painel] ' + (e instanceof ErroDeConfiguracao ? e.message : 'configuração inválida'));
    process.exit(1);
  }
  // Ainda como root (o `docker run` do app não define usuário): entrega a pasta de dados e troca para um usuário comum.
  const r = reduzirPrivilegios({ socketDocker: configuracao.dockerSocket, pastas: [configuracao.dadosDir] });
  if (!r.ok) {
    console.error('[painel] ' + r.erro);
    process.exit(1);
  }
  if (r.aviso) console.error('[painel] aviso: ' + r.aviso);
  if (r.mudou) console.log('[painel] rodando como usuário comum (uid ' + r.uid + ')');

  let app;
  try { app = criarServidor({ configuracao }); } catch (e) {
    // pasta de dados que não dá para criar ou ler (permissão): uma frase, sem pilha nem caminho
    console.error('[painel] não consegui preparar a pasta de dados (' + (e && e.code ? e.code : 'erro') + ')');
    process.exit(1);
  }
  process.on('exit', () => { if (app.gravador.suja()) app.gravador.salvar(); });
  let saindo = false;
  const encerrar = () => {
    if (saindo) return;
    saindo = true;
    setTimeout(() => process.exit(0), 5000).unref();
    app.fechar().then(() => process.exit(0));
  };
  process.on('SIGTERM', encerrar);
  process.on('SIGINT', encerrar);
  // Erro que ninguém previu: registra só a mensagem e sai (o Docker reinicia). Seguir "no ar" com estado desconhecido é pior.
  process.on('uncaughtException', (e) => { console.error('[painel] erro não tratado: ' + String(e && e.message).slice(0, 200)); process.exit(1); });
  process.on('unhandledRejection', (e) => { console.error('[painel] promessa rejeitada: ' + String(e && e.message).slice(0, 200)); process.exit(1); });

  app.metricas.iniciar();
  app.servidor.listen(configuracao.porta, configuracao.enderecoDeEscuta, () => {
    console.log('Agente do Lab Desktop em http://' + configuracao.enderecoDeEscuta + ':' + configuracao.porta + ' (perfil ' + PERFIL + ', escuta ' + configuracao.escuta + ', 2FA ' + acesso.totpPublico() + ')');
  });
  app.servidor.on('error', (e) => {
    console.error('[painel] não consegui escutar na porta ' + configuracao.porta + ' (' + (e && e.code) + ')');
    process.exit(1);
  });
}

if (require.main === module) iniciar();

module.exports = { criarServidor, lerConfiguracao, ErroDeConfiguracao, RECURSOS, PERFIL, LIMITES_HTTP };
