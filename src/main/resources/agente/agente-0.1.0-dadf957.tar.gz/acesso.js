'use strict';
/*
  acesso.js: quem pode falar com o agente.

  Toda chamada precisa de um token (cabeçalho `Authorization: Bearer lab_...`).
  Não existe modo sem token. O app gera 32 bytes aleatórios, guarda o texto
  (lab_...) no cofre dele e registra aqui SÓ o SHA-256, por um comando local:
  `docker exec -i <container> node acesso.js token-registrar` (a entrada vai por
  stdin, nunca por argumento, que aparece em `ps` e no histórico do shell).

  Com o 2FA ligado (TOTP, RFC 6238, o código do aplicativo autenticador), um token
  que ainda não confirmou o código só alcança POST /api/acesso/2fa.

  Dois arquivos na pasta de dados, ambos com modo 0600:
  - tokens-clientes.json: { versao, tokens: [{ hash, nome_do_dispositivo, criado_em,
    ativado_ate }] }. Relido quando muda (no máximo a cada 2 s), então
    registrar ou revogar não pede reiniciar o agente.
  - acesso-totp.json: { versao, segredo (base32), ativo, criado_em, confirmado_em,
    ultimo_contador }. Sem o arquivo o 2FA está desligado; com `ativo: false` está
    pendente (gerado e ainda não confirmado: não exige nada, para configurar nunca
    trancar ninguém do lado de fora no meio do caminho).
    O segredo fica em texto no arquivo porque o servidor precisa dele para calcular
    o HMAC; criptografá-lo com uma chave guardada na mesma máquina não protegeria de
    nada. A proteção é o modo 0600, a pasta de dados privada e o segredo aparecer uma
    única vez (na hora de configurar).

  Duas famílias de escritor mexem nos mesmos arquivos: o agente (ativado_ate e o contador de erros
  do 2FA, ao confirmar um código) e a linha de comando abaixo. O agente NÃO grava nada a cada requisição
  (o "último uso" de um token só existe em memória). Toda gravação é atômica (temporário 0600 na mesma
  pasta, feito por descritor de arquivo, + rename), relê o arquivo logo antes de alterar e confere depois que
  a mudança ficou; e todo comando que grava (a linha de comando inteira e a confirmação do 2FA) roda sob uma
  TRAVA de arquivo (`.acesso.trava`, criada com O_EXCL, com prazo de 5 s e trava abandonada descartada depois de
  10 s), então duas gravações nunca se pisam: um token revogado não volta.

  Falha FECHADA: arquivo do 2FA que existe mas não é legível conta como 2FA ativo
  (recusa em vez de abrir); arquivo de tokens ilegível ou ausente = ninguém autorizado.
  Node puro, sem dependências (totp.js usa só `crypto`).
*/
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const totp = require('./totp.js');

const DADOS_PADRAO = '/srv/painel/dados'; // dentro do container; o volume de dados é montado aqui
const BEARER_RE = /^Bearer (lab_[A-Za-z0-9_-]{43})$/;
const NOME_RE = /^[a-z0-9-]{1,40}$/;
const HASH_RE = /^[0-9a-f]{64}$/;
const DIGITOS_RE = /^[0-9]{6}$/;
const ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?Z$/; // Instant.toString() do app: 0 a 9 casas decimais
const RELER_MS = 2000; // confere o arquivo no máximo a cada 2 s
const VALIDADE_2FA_MS = 30 * 24 * 3600 * 1000; // 30 dias por confirmação; o uso não renova
const ERROS_PARA_BLOQUEAR = 5; // códigos 2FA errados seguidos, por token
const BLOQUEIO_MS = 60 * 1000;
const TRAVA_NOME = '.acesso.trava';
const TRAVA_ESPERA_MS = 5000; // quanto tempo esperar a trava
const TRAVA_ABANDONADA_MS = 10000; // uma trava mais velha que isto é de um processo que morreu
const SEGREDO_MIN_BYTES = 16; // o agente gera 20; menos que 128 bits num arquivo editado à mão é lixo
const MAXIMO_DE_TOKENS = 32; // limita o trabalho por requisição: cada uma compara com todos
const TENTATIVAS_GRAVACAO = 3;
const MODO_PRIVADO = 0o600;
const LIMITE_ENTRADA = 8 * 1024; // stdin dos comandos: uma linha de JSON ou um código
const ESPERA_DEPOIS_DA_LINHA_MS = 300; // o app pode não fechar o stdin: depois da 1a linha, só espera a 2a (opcional)
const ESPERA_ENTRADA_MS = 10000;
const ILEGIVEL = Object.freeze({ ilegivel: true }); // o arquivo existe mas não é um objeto JSON legível

const cfg = { tokens: null, totp: null, agora: Date.now };
let lidos = {}; // por arquivo: { assinatura, quando, dado }
let falhas = {}; // por hash: { erros, ate }; cópia em memória (a que vale está em acesso-totp.json, e sobrevive a reinício)
let ultimoUso = Object.create(null); // só em memória

const iso = (ms) => new Date(ms).toISOString();

function init(opts) {
  cfg.tokens = opts.tokens;
  cfg.totp = opts.totp; // pode não existir
  cfg.agora = opts.agora || Date.now;
  lidos = {};
  falhas = {};
  ultimoUso = Object.create(null);
  // cria o arquivo vazio (0600) para o volume já tê-lo; nunca sobrescreve um que existe
  try {
    fs.writeFileSync(cfg.tokens, JSON.stringify({ versao: 1, tokens: [] }, null, 2) + '\n', { flag: 'wx', mode: MODO_PRIVADO });
  } catch (e) {
    if (e.code !== 'EEXIST') console.error('[acesso] não consegui criar o arquivo de tokens (' + e.code + ')');
  }
}

/* ======================================================================
   Disco: leitura com cache, escrita atômica
   ====================================================================== */

// null = o arquivo não existe; ILEGIVEL = existe mas não dá para ler ou não é um objeto JSON.
// `null` e `[]` são JSON válidos e NÃO podem passar por "arquivo inexistente": um
// acesso-totp.json com o texto "null" desligaria o 2FA.
function lerArquivoJson(arq) {
  let txt;
  try { txt = fs.readFileSync(arq, 'utf8'); } catch (e) { return e.code === 'ENOENT' ? null : ILEGIVEL; }
  try {
    const d = JSON.parse(txt);
    return d && typeof d === 'object' && !Array.isArray(d) ? d : ILEGIVEL;
  } catch (e) { return ILEGIVEL; }
}

// A assinatura leva tamanho e inode além do mtime: a gravação atômica troca o
// inode, então duas gravações no mesmo milissegundo ainda são vistas.
function lerJson(arq) {
  const c = lidos[arq] || (lidos[arq] = { assinatura: null, quando: -Infinity, dado: null });
  const agora = cfg.agora();
  if (agora - c.quando < RELER_MS) return c.dado;
  c.quando = agora;
  let st;
  try { st = fs.statSync(arq); } catch (e) {
    c.assinatura = null;
    c.dado = e.code === 'ENOENT' ? null : ILEGIVEL;
    return c.dado;
  }
  const assinatura = st.mtimeMs + ':' + st.size + ':' + st.ino;
  if (assinatura !== c.assinatura) {
    c.dado = lerArquivoJson(arq);
    c.assinatura = c.dado && c.dado !== ILEGIVEL ? assinatura : null; // sem assinatura = relê no próximo ciclo
  }
  return c.dado;
}

// Rodado como root (docker exec) o arquivo nasceria de root e o agente, que roda como usuário comum, deixaria de
// lê-lo: viraria "ninguém autorizado" sem aviso. Herda o proprietário da pasta. Por DESCRITOR, não por caminho:
// nada pode trocar o arquivo por outro entre a criação e a mudança de proprietário.
function herdarDono(fd, arq) {
  if (typeof process.getuid !== 'function' || process.getuid() !== 0) return;
  const st = fs.statSync(path.dirname(arq));
  fs.fchownSync(fd, st.uid, st.gid);
}

function gravar(arq, obj) {
  const tmp = arq + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
  let fd = null;
  try {
    fd = fs.openSync(tmp, 'wx', MODO_PRIVADO);
    fs.fchmodSync(fd, MODO_PRIVADO); // o umask do processo não pode afrouxar o 0600
    herdarDono(fd, arq);
    fs.writeSync(fd, JSON.stringify(obj, null, 2) + '\n');
    fs.fsyncSync(fd);
    fs.closeSync(fd);
    fd = null;
    fs.renameSync(tmp, arq);
  } catch (e) {
    if (fd !== null) { try { fs.closeSync(fd); } catch (e2) { /* já fechado */ } }
    try { fs.unlinkSync(tmp); } catch (e2) { /* o temporário nem chegou a existir */ }
    throw e;
  }
  delete lidos[arq];
}

function dormir(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

// Trava de arquivo para quem GRAVA nos arquivos de acesso (a linha de comando e a confirmação do 2FA). Cria
// `.acesso.trava` com O_EXCL; quem não consegue espera até 5 s. Uma trava de mais de 10 s é de um processo que morreu.
function comTrava(fn) {
  const trava = path.join(path.dirname(cfg.tokens), TRAVA_NOME);
  const limite = Date.now() + TRAVA_ESPERA_MS;
  let fd = null;
  while (fd === null) {
    try {
      fd = fs.openSync(trava, 'wx', MODO_PRIVADO);
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      try {
        if (Date.now() - fs.statSync(trava).mtimeMs > TRAVA_ABANDONADA_MS) fs.unlinkSync(trava);
      } catch (e2) { /* sumiu entre a checagem e agora: tenta de novo */ }
      if (Date.now() > limite) throw new Error('a trava dos arquivos de acesso não liberou');
      dormir(15);
    }
  }
  try {
    return fn();
  } finally {
    try { fs.closeSync(fd); } catch (e) { /* já fechado */ }
    try { fs.unlinkSync(trava); } catch (e) { /* já foi */ }
  }
}

// Lê o arquivo de novo (sem cache), deixa `mutar` alterar o objeto, grava e confere.
// `mutar` devolve false para "nada a gravar". Lança se o arquivo sumiu ou não é legível.
function alterarArquivo(arq, mutar, conferir) {
  for (let i = 0; i < TENTATIVAS_GRAVACAO; i++) {
    const d = lerArquivoJson(arq);
    if (d === null || d === ILEGIVEL) throw new Error('arquivo ausente ou ilegível: ' + path.basename(arq));
    if (mutar(d) === false) return false;
    gravar(arq, d);
    const depois = lerArquivoJson(arq);
    if (!conferir || (depois && depois !== ILEGIVEL && conferir(depois))) return true;
  }
  throw new Error('a gravação de ' + path.basename(arq) + ' foi perdida em disputa com outro processo');
}

/* ======================================================================
   Estado dos arquivos
   ====================================================================== */

function tokens() {
  const d = lerJson(cfg.tokens);
  if (!d || d === ILEGIVEL || !Array.isArray(d.tokens)) return []; // sem arquivo = ninguém autorizado
  return d.tokens.filter((t) => t && HASH_RE.test(t.hash) && NOME_RE.test(t.nome_do_dispositivo || '')).slice(0, MAXIMO_DE_TOKENS);
}

// 'desligado' (sem arquivo), 'pendente' (segredo gerado, ainda não confirmado: NÃO exige),
// 'ativo', ou 'ilegivel' (tratado como ativo: falha fechada). Qualquer campo fora do
// formato também é 'ilegivel': `"ativo": "true"` (texto) não pode virar "pendente".
function classificarTotp(d) {
  const ilegivel = { estado: 'ilegivel' };
  if (d === null) return { estado: 'desligado' };
  if (d === ILEGIVEL) return ilegivel;
  const segredo = typeof d.segredo === 'string' ? totp.base32Decodificar(d.segredo) : null;
  if (!segredo || segredo.length < SEGREDO_MIN_BYTES) return ilegivel;
  const uc = d.ultimo_contador;
  if (!(uc === null || uc === undefined || (typeof uc === 'number' && uc >= 0 && uc === Math.floor(uc)))) return ilegivel;
  if (d.ativo === true) return { estado: 'ativo', dado: d, segredo };
  if (d.ativo === false) return { estado: 'pendente', dado: d, segredo };
  return ilegivel;
}
const estadoTotp = () => classificarTotp(lerJson(cfg.totp)).estado;

// Valor de "totp" em /api/versao: o app só precisa saber se oferece Configurar ou
// Desativar. Lê o arquivo de novo (sem o cache de 2 s): é uma rota rara e o app a
// consulta logo depois de configurar ou desativar, quando o estado velho confundiria a tela.
function totpPublico() {
  delete lidos[cfg.totp];
  const e = estadoTotp();
  return e === 'ilegivel' ? 'ativo' : e;
}

function precisa2fa(t) {
  const e = estadoTotp();
  if (e !== 'ativo' && e !== 'ilegivel') return false;
  return !(t.ativado_ate && Date.parse(t.ativado_ate) > cfg.agora());
}

// SHA-256 do token recebido contra cada hash guardado, em tempo constante e sem parada
// antecipada: o tempo de resposta não diz qual linha casou nem quantas há.
function procurarToken(valor) {
  const hash = crypto.createHash('sha256').update(valor).digest();
  let achado = null;
  for (const t of tokens()) {
    const igual = crypto.timingSafeEqual(hash, Buffer.from(t.hash, 'hex'));
    if (igual && !achado) achado = t;
  }
  return achado;
}

// Informativo (quando o agente viu o token pela última vez): só em memória, nada vai ao disco por requisição.
function registrarUso(t) {
  ultimoUso[t.hash] = cfg.agora();
}
function achar(lista, hash) {
  for (const x of lista) if (x && x.hash === hash) return x;
  return null;
}

/* ======================================================================
   Decisão de acesso
   ====================================================================== */

/*
  Devolve:
    { tipo: 'cliente', nome, hash }  token válido e, se o 2FA está ativo, confirmado
    { tipo: 'negado', contaTentativa: true }   sem token, token mal formado ou desconhecido
    { tipo: 'negado', codigo: 'totp_requerido', erro }   token válido, falta o código do autenticador
  `contaTentativa` diz ao limitador de tentativas se a recusa conta como palpite errado.
  A única rota que um token ainda não confirmado alcança é POST /api/acesso/2fa.
*/
function avaliar(req) {
  const h = req.headers.authorization;
  const caminho = String(req.url || '').split('?')[0];
  if (h === undefined) return { tipo: 'negado', contaTentativa: true };
  const m = BEARER_RE.exec(String(h));
  if (!m) return { tipo: 'negado', contaTentativa: true };
  let achado = procurarToken(m[1]);
  if (!achado) return { tipo: 'negado', contaTentativa: true };
  if (precisa2fa(achado)) {
    // Antes de recusar, relê os dois arquivos sem cache: o app acaba de confirmar ou
    // desativar o 2FA e o cache tem até 2 s; recusar com o estado velho abriria o
    // diálogo de código sem motivo.
    delete lidos[cfg.tokens];
    delete lidos[cfg.totp];
    const hashAchado = achado.hash;
    achado = tokens().find((t) => t.hash === hashAchado) || null;
    if (!achado) return { tipo: 'negado', contaTentativa: true }; // revogado neste meio tempo
  }
  const id = { tipo: 'cliente', nome: achado.nome_do_dispositivo, hash: achado.hash };
  if (precisa2fa(achado)) {
    if (req.method === 'POST' && caminho === '/api/acesso/2fa') return id;
    return { tipo: 'negado', codigo: 'totp_requerido', erro: 'Confirme o código do autenticador.' };
  }
  registrarUso(achado);
  return id;
}

/*
  Limite de tentativas por endereço de origem: depois de `max` recusas de credencial
  dentro da janela, toda requisição desse endereço (até a que traz o token certo) leva
  429 por `bloqueioMs`. O token tem 256 bits, então adivinhá-lo já é inviável; o limite
  existe para não deixar ninguém martelar o agente nem encher o log. Atrás da porta
  publicada pelo Docker todos os clientes parecem vir do mesmo endereço: o bloqueio vale
  para todos eles (aceito e documentado).
*/
function criarLimitador(opcoes = {}) {
  const max = opcoes.max || 30;
  const janelaMs = opcoes.janelaMs || 60000;
  const bloqueioMs = opcoes.bloqueioMs || 60000;
  const relogio = opcoes.relogio || Date.now;
  const capacidade = opcoes.capacidade || 1024;
  const porEndereco = new Map();

  return {
    // milissegundos que faltam para o endereço poder tentar de novo (0 = livre)
    espera(endereco) {
      const e = porEndereco.get(endereco);
      return e && e.ate > relogio() ? e.ate - relogio() : 0;
    },
    registrarFalha(endereco) {
      const agora = relogio();
      let e = porEndereco.get(endereco);
      if (!e || agora - e.inicio > janelaMs) {
        if (!e && porEndereco.size >= capacidade) porEndereco.delete(porEndereco.keys().next().value); // o mais antigo sai
        e = { inicio: agora, n: 0, ate: 0 };
        porEndereco.set(endereco, e);
      }
      e.n += 1;
      if (e.n >= max) {
        e.ate = agora + bloqueioMs;
        e.n = 0;
        e.inicio = agora;
        return true; // acabou de bloquear
      }
      return false;
    },
    tamanho: () => porEndereco.size
  };
}

function bloqueado(ms) {
  const s = Math.ceil(ms / 1000);
  return { status: 429, corpo: { erro: 'Muitas tentativas. Aguarde ' + s + ' s.', codigo: 'totp_bloqueado', aguarde_s: s } };
}

// Erros seguidos de um token no 2FA: vale o que está em acesso-totp.json (campo `falhas`, que sobrevive a reinício do
// agente; sem isso, reiniciar zeraria o bloqueio) e, se for mais severo, a cópia em memória (disco que não grava não pode
// desligar o bloqueio).
function falhaAtual(t, hash) {
  const mem = falhas[hash] || { erros: 0, ate: 0 };
  const f = t.dado && t.dado.falhas && typeof t.dado.falhas === 'object' && !Array.isArray(t.dado.falhas) ? t.dado.falhas[hash] : null;
  if (!f || !Number.isInteger(f.erros) || f.erros < 0 || !Number.isFinite(f.ate) || f.ate < 0) return mem;
  return f.ate > mem.ate || (f.ate === mem.ate && f.erros > mem.erros) ? { erros: f.erros, ate: f.ate } : mem;
}

function gravarFalha(hash, f, agora) {
  falhas[hash] = f;
  try {
    alterarArquivo(cfg.totp, (d) => {
      const lista = d.falhas && typeof d.falhas === 'object' && !Array.isArray(d.falhas) ? d.falhas : {};
      for (const [h, x] of Object.entries(lista)) if (!x || (x.erros === 0 && !(x.ate > agora))) delete lista[h]; // o que já expirou sai
      if (f.erros === 0 && !(f.ate > agora)) delete lista[hash]; else lista[hash] = { erros: f.erros, ate: f.ate };
      d.falhas = lista;
      return true;
    });
  } catch (e) { /* a cópia em memória segura até o disco voltar */ }
}

// POST /api/acesso/2fa: devolve { status, corpo }. Nunca lança: o arquivo pode sumir entre
// a checagem e a leitura. O código digitado não vai para o log. Roda sob a trava dos arquivos de acesso.
function confirmar2fa(cred, corpo) {
  if (!cred || cred.tipo !== 'cliente') return { status: 401, corpo: { erro: 'Token ausente ou inválido.' } };
  try {
    return comTrava(() => confirmar2faSobTrava(cred, corpo));
  } catch (e) {
    console.error('[acesso] falha ao confirmar o 2FA');
    return { status: 500, corpo: { erro: 'Não consegui ler ou gravar o estado do 2FA no servidor.' } };
  }
}

function confirmar2faSobTrava(cred, corpo) {
  const agora = cfg.agora();
  const t = classificarTotp(lerArquivoJson(cfg.totp)); // sem cache: o estado de 2 s atrás não vale aqui
  if (t.estado === 'desligado' || t.estado === 'pendente') {
    return { status: 409, corpo: { erro: 'O 2FA não está ativo neste servidor.', codigo: 'totp_nao_configurado' } };
  }
  if (t.estado === 'ilegivel') {
    console.error('[acesso] acesso-totp.json ilegível: 2FA tratado como ativo');
    return { status: 500, corpo: { erro: 'Não consegui ler a configuração do 2FA no servidor.' } };
  }
  const f = falhaAtual(t, cred.hash);
  if (agora < f.ate) return bloqueado(f.ate - agora);
  const codigoErrado = () => {
    const erros = f.erros + 1;
    if (erros < ERROS_PARA_BLOQUEAR) {
      gravarFalha(cred.hash, { erros, ate: 0 }, agora);
      return { status: 401, corpo: { erro: 'Código incorreto ou já usado.', codigo: 'totp_incorreto' } };
    }
    gravarFalha(cred.hash, { erros: 0, ate: agora + BLOQUEIO_MS }, agora);
    console.log('[acesso] ' + ERROS_PARA_BLOQUEAR + ' códigos 2FA errados seguidos (cliente=' + cred.nome + '): recusando por ' + BLOQUEIO_MS / 1000 + ' s');
    return bloqueado(BLOQUEIO_MS);
  };
  const codigo = corpo && typeof corpo.codigo === 'string' ? corpo.codigo.replace(/\s/g, '') : '';
  if (!DIGITOS_RE.test(codigo)) return { status: 400, corpo: { erro: 'Informe o código de 6 dígitos.', codigo: 'totp_formato' } };
  const c = totp.verificar(t.segredo, codigo, agora, t.dado.ultimo_contador);
  if (c === null) return codigoErrado();
  // O contador primeiro: o código não pode valer duas vezes, nem se a gravação seguinte
  // falhar. Se outro processo já gravou um contador igual ou maior, este código já foi usado.
  const gravouContador = alterarArquivo(cfg.totp, (d) => {
    if (typeof d.ultimo_contador === 'number' && d.ultimo_contador >= c) return false;
    d.ultimo_contador = c;
    return true;
  }, (d) => d.ultimo_contador === c);
  if (!gravouContador) return codigoErrado();
  gravarFalha(cred.hash, { erros: 0, ate: 0 }, agora);
  const ate = iso(agora + VALIDADE_2FA_MS);
  let achou = false;
  alterarArquivo(cfg.tokens, (d) => {
    const x = achar(d.tokens, cred.hash);
    if (!x) return false;
    achou = true;
    x.ativado_ate = ate;
    return true;
  }, (d) => { const x = achar(d.tokens, cred.hash); return !!x && x.ativado_ate === ate; });
  if (!achou) return { status: 401, corpo: { erro: 'Token ausente ou inválido.' } }; // revogado entre a checagem e agora
  return { status: 200, corpo: { ok: true, ativado_ate: ate } };
}

/* ======================================================================
   Linha de comando: node acesso.js <comando>
   Nada sensível em argv: código, segredo e hash vão por stdin. Cada comando imprime UMA
   linha JSON no stdout e sai com 0 (sucesso) ou 1 (falha): { ok: false, codigo, erro }.
   Os totp-* não têm o limite de 5 erros: quem os roda já tem acesso ao servidor.
   ====================================================================== */

const falha = (codigo, erro) => ({ ok: false, codigo, erro });
const linhasDe = (entrada) => String(entrada || '').split(/\r?\n/);

// O nome do servidor no autenticador: o nome da máquina (o arquivo dela montado no container; fora disso, o hostname
// do próprio processo) reduzido ao que a URI aceita sem surpresa.
function nomeDoServidor() {
  let bruto = '';
  try { bruto = fs.readFileSync(path.join(process.env.PAINEL_HOST_DIR || '/host', 'etc/hostname'), 'utf8').split('\n')[0]; } catch (e) { /* sem o arquivo da máquina */ }
  const n = String(bruto.trim() || os.hostname() || '').replace(/[^A-Za-z0-9._-]/g, '').slice(0, 64);
  return n || 'servidor';
}

// { dado } do arquivo de tokens, { dado: vazio, existe: false } se ainda não há arquivo, ou
// null se existe e não dá para ler (nunca sobrescrevemos o que não entendemos).
function tokensAgora() {
  const d = lerArquivoJson(cfg.tokens);
  if (d === null) return { dado: { versao: 1, tokens: [] }, existe: false };
  if (d === ILEGIVEL || !Array.isArray(d.tokens)) return null;
  return { dado: d, existe: true };
}
const FALHA_TOKENS_ILEGIVEL = falha('tokens_ilegivel', 'O arquivo tokens-clientes.json existe mas não é legível. Corrija ou mova o arquivo antes de continuar.');
const FALHA_TOTP_ILEGIVEL = falha('totp_ilegivel', 'O arquivo acesso-totp.json existe mas não é legível (o agente o trata como 2FA ativo). Apague-o e configure o 2FA de novo.');

function zerarAtivacoes(d) {
  let mudou = false;
  for (const t of d.tokens) {
    if (t && t.ativado_ate !== null) {
      t.ativado_ate = null;
      mudou = true;
    }
  }
  return mudou;
}

function cmdTotpIniciar() {
  const t = classificarTotp(lerArquivoJson(cfg.totp));
  if (t.estado === 'ativo') return falha('totp_ja_ativo', 'O 2FA já está ativo neste servidor. Para trocar de celular, desative com um código válido e configure de novo.');
  if (t.estado === 'ilegivel') return FALHA_TOTP_ILEGIVEL;
  // desligado ou pendente: gera segredo novo (o QR de uma tentativa anterior deixa de valer)
  const b32 = totp.base32Codificar(totp.novoSegredo());
  gravar(cfg.totp, { versao: 1, segredo: b32, ativo: false, criado_em: iso(cfg.agora()), confirmado_em: null, ultimo_contador: null });
  return { ok: true, segredo: b32, uri: totp.uri(b32, nomeDoServidor()) };
}

function cmdTotpConfirmar(entrada) {
  const linhas = linhasDe(entrada);
  const t = classificarTotp(lerArquivoJson(cfg.totp));
  if (t.estado !== 'pendente') return falha('totp_nao_pendente', 'Não há 2FA pendente de confirmação neste servidor. Rode "Configurar 2FA" de novo.');
  const codigo = (linhas[0] || '').replace(/\s/g, '');
  if (!DIGITOS_RE.test(codigo)) return falha('totp_formato', 'Informe o código de 6 dígitos.');
  const nome = (linhas[1] || '').trim();
  const tk = tokensAgora();
  if (tk === null) return FALHA_TOKENS_ILEGIVEL;
  // A linha 2 é conferida ANTES de qualquer gravação: nome inválido ou desconhecido não
  // pode consumir o código (o mesmo código não valeria de novo).
  if (nome !== '') {
    if (!NOME_RE.test(nome)) return falha('entrada_invalida', 'nome_do_dispositivo inválido.');
    if (!tk.dado.tokens.some((x) => x && x.nome_do_dispositivo === nome)) return falha('token_inexistente', 'Não existe token registrado com esse nome.');
  }
  const agora = cfg.agora();
  const c = totp.verificar(t.segredo, codigo, agora, t.dado.ultimo_contador);
  if (c === null) return falha('totp_incorreto', 'Código incorreto ou já usado.');
  // Ordem: tokens-clientes.json primeiro, acesso-totp.json depois. Se cair no meio, o 2FA
  // segue pendente (não exige nada) e a pessoa confirma de novo.
  const ate = nome !== '' ? iso(agora + VALIDADE_2FA_MS) : null;
  if (tk.existe) {
    // confirmações de um segredo anterior não valem para o novo: zera todas e ativa só o token do app
    alterarArquivo(cfg.tokens, (d) => {
      let mudou = zerarAtivacoes(d);
      const x = nome !== '' ? d.tokens.find((y) => y && y.nome_do_dispositivo === nome) : null;
      if (x) {
        x.ativado_ate = ate;
        mudou = true;
      }
      return mudou;
    }, (d) => nome === '' || d.tokens.some((y) => y && y.nome_do_dispositivo === nome && y.ativado_ate === ate));
  }
  alterarArquivo(cfg.totp, (d) => {
    d.ativo = true;
    d.confirmado_em = iso(agora);
    d.ultimo_contador = c;
    return true;
  }, (d) => d.ativo === true && d.ultimo_contador === c);
  return { ok: true, ativado_ate: ate };
}

function cmdTotpDesativar(entrada) {
  const t = classificarTotp(lerArquivoJson(cfg.totp));
  if (t.estado === 'ilegivel') return FALHA_TOTP_ILEGIVEL;
  if (t.estado !== 'ativo') return falha('totp_nao_ativo', 'O 2FA não está ativo neste servidor.');
  const codigo = (linhasDe(entrada)[0] || '').replace(/\s/g, '');
  if (!DIGITOS_RE.test(codigo)) return falha('totp_formato', 'Informe o código de 6 dígitos.');
  const tk = tokensAgora();
  if (tk === null) return FALHA_TOKENS_ILEGIVEL;
  if (totp.verificar(t.segredo, codigo, cfg.agora(), t.dado.ultimo_contador) === null) return falha('totp_incorreto', 'Código incorreto ou já usado.');
  fs.unlinkSync(cfg.totp);
  delete lidos[cfg.totp];
  if (tk.existe) alterarArquivo(cfg.tokens, zerarAtivacoes, (d) => d.tokens.every((x) => !x || x.ativado_ate === null));
  return { ok: true };
}

function cmdTokenRegistrar(entrada) {
  let e;
  try { e = JSON.parse(linhasDe(entrada)[0] || ''); } catch (err) { e = null; }
  if (!e || typeof e !== 'object' || Array.isArray(e) ||
      typeof e.hash !== 'string' || !HASH_RE.test(e.hash) ||
      typeof e.nome_do_dispositivo !== 'string' || !NOME_RE.test(e.nome_do_dispositivo) ||
      typeof e.criado_em !== 'string' || !ISO_RE.test(e.criado_em) || Number.isNaN(Date.parse(e.criado_em))) {
    return falha('entrada_invalida', 'Esperava uma linha JSON com hash (sha256 em hexadecimal minúsculo), nome_do_dispositivo (a-z, 0-9 e hífen, até 40) e criado_em (ISO 8601 UTC).');
  }
  const tk = tokensAgora();
  if (tk === null) return FALHA_TOKENS_ILEGIVEL;
  let porHash = null;
  let porNome = null;
  for (const x of tk.dado.tokens) {
    if (!x) continue;
    if (x.hash === e.hash) porHash = x;
    if (x.nome_do_dispositivo === e.nome_do_dispositivo) porNome = x;
  }
  if (porHash && porNome && porHash === porNome) return { ok: true, ja_existia: true }; // repetir o mesmo registro é idempotente
  if (porHash || porNome) return falha('token_conflito', 'Já existe um token com esse nome ou com esse hash, mas não os dois juntos. Revogue o antigo antes de registrar de novo.');
  if (tk.dado.tokens.length >= MAXIMO_DE_TOKENS) return falha('tokens_demais', 'O limite de ' + MAXIMO_DE_TOKENS + ' dispositivos foi atingido. Revogue um antes de registrar outro.');
  const nova = { hash: e.hash, nome_do_dispositivo: e.nome_do_dispositivo, criado_em: e.criado_em, ativado_ate: null };
  const conferir = (d) => !!achar(d.tokens, e.hash);
  if (!tk.existe) {
    gravar(cfg.tokens, { versao: 1, tokens: [nova] });
    if (!conferir(lerArquivoJson(cfg.tokens))) throw new Error('a gravação de tokens-clientes.json foi perdida');
  } else {
    // A conferência de conflito repete dentro da gravação: o arquivo é relido ali e outro
    // registro pode ter entrado desde a leitura de cima.
    let disputou = false;
    alterarArquivo(cfg.tokens, (d) => {
      if (achar(d.tokens, e.hash) || d.tokens.some((x) => x && x.nome_do_dispositivo === e.nome_do_dispositivo)) {
        disputou = true;
        return false;
      }
      d.tokens.push(nova);
      return true;
    }, conferir);
    if (disputou) return falha('token_conflito', 'Outro registro com esse nome ou hash entrou ao mesmo tempo. Consulte o estado e tente de novo.');
  }
  return { ok: true, ja_existia: false };
}

function cmdTokenRevogar(entrada) {
  const nome = (linhasDe(entrada)[0] || '').trim();
  if (!NOME_RE.test(nome)) return falha('entrada_invalida', 'Esperava o nome_do_dispositivo (a-z, 0-9 e hífen, até 40) na primeira linha.');
  const tk = tokensAgora();
  if (tk === null) return FALHA_TOKENS_ILEGIVEL;
  const inexistente = falha('token_inexistente', 'Não existe token registrado com esse nome.');
  if (!tk.existe) return inexistente;
  const removeu = alterarArquivo(cfg.tokens, (d) => {
    const antes = d.tokens.length;
    d.tokens = d.tokens.filter((x) => !(x && x.nome_do_dispositivo === nome));
    return d.tokens.length !== antes;
  }, (d) => !d.tokens.some((x) => x && x.nome_do_dispositivo === nome));
  return removeu ? { ok: true } : inexistente;
}

const COMANDOS = new Map([
  ['totp-iniciar', cmdTotpIniciar],
  ['totp-confirmar', cmdTotpConfirmar],
  ['totp-desativar', cmdTotpDesativar],
  ['token-registrar', cmdTokenRegistrar],
  ['token-revogar', cmdTokenRevogar]
]);

// Devolve o objeto que vira a linha de saída; a falha tem ok: false.
function rodarComando(comando, entrada) {
  if (!COMANDOS.has(comando)) {
    return falha('comando_desconhecido', 'Comando desconhecido. Use: totp-iniciar, totp-confirmar, totp-desativar, token-registrar ou token-revogar.');
  }
  try { return comTrava(() => COMANDOS.get(comando)(entrada)); } catch (e) { return falha('falha_interna', 'Não consegui concluir o comando.'); }
}

// stdin: termina no fim da entrada, ou pouco depois da primeira linha completa (o app pode
// não fechar o stdin), ou com erro se nada chegar em 10 s.
function lerEntrada(cb) {
  let texto = '';
  let terminou = false;
  let depoisDaLinha = null;
  const limite = setTimeout(() => terminar(new Error('A entrada não terminou a tempo.')), ESPERA_ENTRADA_MS);
  function terminar(err) {
    if (terminou) return;
    terminou = true;
    clearTimeout(limite);
    clearTimeout(depoisDaLinha);
    process.stdin.pause();
    cb(err, texto);
  }
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', (pedaco) => {
    texto += pedaco;
    if (texto.length > LIMITE_ENTRADA) return terminar(new Error('Entrada grande demais.'));
    if (!depoisDaLinha && texto.includes('\n')) depoisDaLinha = setTimeout(() => terminar(null), ESPERA_DEPOIS_DA_LINHA_MS);
    return undefined;
  });
  process.stdin.on('end', () => terminar(null));
  process.stdin.on('error', (e) => terminar(e));
}

function responder(codigoSaida, obj) {
  process.stdout.on('error', () => process.exit(codigoSaida)); // quem lê fechou o pipe
  process.stdout.write(JSON.stringify(obj) + '\n', () => process.exit(codigoSaida));
}

function principal(argv) {
  const dir = process.env.PAINEL_DADOS_DIR || DADOS_PADRAO;
  cfg.tokens = path.join(dir, 'tokens-clientes.json');
  cfg.totp = path.join(dir, 'acesso-totp.json');
  const comando = argv[2];
  const concluir = (entrada) => {
    const r = rodarComando(comando, entrada);
    responder(r.ok === false ? 1 : 0, r);
  };
  // totp-iniciar não lê stdin: o app pode deixá-lo aberto e o comando travaria esperando
  if (comando === 'totp-iniciar' || !COMANDOS.has(comando)) return concluir('');
  return lerEntrada((err, texto) => {
    if (err) return responder(1, falha('entrada_invalida', err.message));
    return concluir(texto);
  });
}

if (require.main === module) principal(process.argv);

module.exports = {
  init,
  avaliar,
  confirmar2fa,
  totpPublico,
  criarLimitador,
  // expostas só para teste
  _interno: { VALIDADE_2FA_MS, ERROS_PARA_BLOQUEAR, BLOQUEIO_MS, TRAVA_ABANDONADA_MS, RELER_MS, MAXIMO_DE_TOKENS, classificarTotp, nomeDoServidor }
};
