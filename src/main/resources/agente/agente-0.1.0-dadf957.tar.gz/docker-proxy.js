'use strict';
/*
  docker-proxy.js: o ÚNICO caminho do agente até o Docker, e só de leitura.

  Por quê: o socket do Docker (/var/run/docker.sock) dá controle da máquina
  inteira. Montá-lo "somente leitura" (`:ro`) NÃO ajuda: o `:ro` só impede apagar
  o arquivo do socket, e quem o alcança ainda cria containers, executa comandos e
  apaga tudo pela API. Por isso o agente nunca monta nada para o Docker além deste
  filtro, que só deixa passar uma lista curta de pedidos GET, e recusa o resto.

  Três partes, da mais pura para a mais "de verdade":

  1. `decidir(metodo, alvo)`: função pura. Recebe o método e o alvo da requisição
     (caminho + query) e diz se pode. Lista BRANCA, não lista negra: o que não está
     escrito aqui é recusado (criar, executar, iniciar, parar, apagar, copiar
     arquivos, anexar, logs, eventos, build, tudo). Caminho com `%`, `..`, `//`,
     contrabarra ou caractere de controle é recusado antes de qualquer comparação.

  2. `criarCliente()`: o que o agente usa por dentro. A função `ler(alvo)` NÃO
     recebe método: só existe GET. Mesmo que um bug mandasse um caminho de escrita,
     `decidir` o recusaria antes de abrir o socket.

  3. `criarProxy()`: um servidor HTTP num socket unix que repassa ao socket real só
     o que `decidir` permite. Serve para separar privilégios: um processo (ou
     container) com acesso ao socket real roda só isto, e o agente recebe apenas o
     socket filtrado (ver README, "Endurecendo"). Também roda sozinho:
       node docker-proxy.js --ouvir /caminho/leitura.sock [--socket /var/run/docker.sock]

  O que o agente lê (e só isto): /info, /system/df e /containers/json (nomes e ids,
  para saber de qual container é cada processo).

  A RESPOSTA também é filtrada, no proxy e no cliente: de /containers/json saem só `Id` e
  `Names`; de /info só seis contadores e a versão; de /system/df só totais. Comando, rótulos,
  montagens, variáveis de ambiente, portas e redes dos containers nunca saem daqui (o comando
  de um container pode ter senha). Quem fala com o proxy de leitura recebe só isso.
  Node puro, sem dependências.
*/
const http = require('http');
const fs = require('fs');

const SOCKET_PADRAO = '/var/run/docker.sock';
const LIMITE_RESPOSTA = 16 * 1024 * 1024; // /system/df de uma máquina com milhares de imagens passa de 1 MiB
const PRAZO_MS = 30000;
const ALVO_MAXIMO = 512;
const USUARIO_DO_PROXY = '10002:10002';

// O alvo inteiro (caminho + query) só pode ter estes caracteres: sem `%` (nada de
// caminho codificado), sem espaço, sem barra invertida, sem controle.
const ALVO_VALIDO = /^\/[A-Za-z0-9/_.=&?-]*$/;
const PREFIXO_DE_VERSAO = /^\/v1\.[0-9]{1,2}(?=\/)/;

const booleano = (v) => /^(0|1|true|false)$/.test(v);
const inteiro = (v) => /^[0-9]{1,4}$/.test(v) && Number(v) >= 1 && Number(v) <= 5000;

// caminho -> métodos aceitos e as chaves de query permitidas (cada uma com seu validador)
const REGRAS = new Map([
  ['/info', { metodos: ['GET'], query: {} }],
  ['/system/df', { metodos: ['GET'], query: {} }],
  ['/containers/json', { metodos: ['GET'], query: { all: booleano, limit: inteiro } }]
]);

function recusa(status, motivo) {
  return { permitir: false, status, motivo };
}

/**
 * Decide se o pedido pode seguir ao Docker. Devolve `{ permitir: true, caminho, query }`
 * (já normalizados, é o que se deve enviar) ou `{ permitir: false, status, motivo }`.
 */
function decidir(metodo, alvo) {
  if (typeof metodo !== 'string' || typeof alvo !== 'string') return recusa(400, 'pedido inválido');
  if (alvo.length > ALVO_MAXIMO || !ALVO_VALIDO.test(alvo) || alvo.includes('..') || alvo.includes('//')) {
    return recusa(400, 'caminho inválido');
  }
  const interrogacao = alvo.indexOf('?');
  let caminho = interrogacao < 0 ? alvo : alvo.slice(0, interrogacao);
  const textoDaQuery = interrogacao < 0 ? '' : alvo.slice(interrogacao + 1);
  caminho = caminho.replace(PREFIXO_DE_VERSAO, '');

  const regra = REGRAS.get(caminho);
  if (!regra) return recusa(403, 'este caminho não é lido pelo agente (somente leitura, lista fechada)');
  const metodoNormal = metodo.toUpperCase();
  if (!regra.metodos.includes(metodoNormal)) return recusa(403, 'somente leitura: o método ' + metodoNormal.slice(0, 16) + ' não é permitido');

  const query = {};
  if (textoDaQuery !== '') {
    for (const par of textoDaQuery.split('&')) {
      const [chave, valor, ...resto] = par.split('=');
      if (resto.length || valor === undefined || chave === '') return recusa(400, 'query inválida');
      const validar = Object.prototype.hasOwnProperty.call(regra.query, chave) ? regra.query[chave] : null;
      if (!validar || !validar(valor)) return recusa(403, 'parâmetro não permitido');
      if (Object.prototype.hasOwnProperty.call(query, chave)) return recusa(400, 'parâmetro repetido');
      query[chave] = valor;
    }
  }
  return { permitir: true, metodo: metodoNormal, caminho, query };
}

function alvoNormalizado(decisao) {
  const chaves = Object.keys(decisao.query).sort();
  return decisao.caminho + (chaves.length ? '?' + chaves.map((k) => k + '=' + decisao.query[k]).join('&') : '');
}

class ErroDocker extends Error {
  constructor(codigo, mensagem) {
    super(mensagem);
    this.name = 'ErroDocker';
    this.codigo = codigo; // 'recusado' | 'indisponivel' | 'status' | 'grande' | 'invalido'
  }
}

/* ---------- filtro da RESPOSTA: só o que o agente usa ---------- */

const numero = (v) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : 0);
const texto = (v, max) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, max) : '');

function resumoDeUso(u) {
  return u && typeof u === 'object' ? { TotalSize: numero(u.TotalSize), TotalCount: numero(u.TotalCount) } : undefined;
}

const FILTROS = new Map([
  ['/info', (i) => {
    const o = i && typeof i === 'object' ? i : {};
    return {
      ServerVersion: texto(o.ServerVersion, 40), ContainersRunning: numero(o.ContainersRunning), ContainersPaused: numero(o.ContainersPaused),
      ContainersStopped: numero(o.ContainersStopped), Containers: numero(o.Containers), Images: numero(o.Images)
    };
  }],
  ['/containers/json', (lista) => (Array.isArray(lista) ? lista.filter((c) => c && typeof c === 'object').map((c) => ({
    Id: texto(c.Id, 64), Names: (Array.isArray(c.Names) ? c.Names : []).slice(0, 4).map((n) => texto(n, 128))
  })) : [])],
  ['/system/df', (df) => {
    const o = df && typeof df === 'object' ? df : {};
    const r = { LayersSize: numero(o.LayersSize) };
    const lista = (v) => (Array.isArray(v) ? v.filter((x) => x && typeof x === 'object') : []);
    // formato novo (…Usage) e, só se faltar, o antigo (listas), reduzido ao tamanho de cada item
    for (const k of ['ImageUsage', 'ContainerUsage', 'VolumeUsage', 'BuildCacheUsage']) if (o[k]) r[k] = resumoDeUso(o[k]);
    if (!o.ContainerUsage) r.Containers = lista(o.Containers).map((x) => ({ SizeRw: numero(x.SizeRw) }));
    if (!o.VolumeUsage) r.Volumes = lista(o.Volumes).map((x) => ({ UsageData: { Size: x.UsageData && typeof x.UsageData.Size === 'number' ? x.UsageData.Size : -1 } }));
    if (!o.BuildCacheUsage) r.BuildCache = lista(o.BuildCache).map((x) => ({ Size: numero(x.Size) }));
    return r;
  }]
]);

function filtrarResposta(caminho, valor) {
  const f = FILTROS.get(caminho);
  if (!f) throw new ErroDocker('recusado', 'sem filtro para este caminho');
  return f(valor);
}

/**
 * O cliente do agente. Só GET, só o que `decidir` permite, resposta com teto de
 * tamanho e prazo. `ler(alvo)` devolve o JSON; lança ErroDocker.
 */
function criarCliente(opcoes = {}) {
  const socket = opcoes.socket || SOCKET_PADRAO;
  const prazoMs = opcoes.prazoMs || PRAZO_MS;
  const limite = opcoes.limite || LIMITE_RESPOSTA;

  function ler(alvo) {
    const decisao = decidir('GET', alvo);
    if (!decisao.permitir || decisao.metodo !== 'GET') {
      return Promise.reject(new ErroDocker('recusado', decisao.motivo || 'pedido recusado'));
    }
    return new Promise((resolve, reject) => {
      let terminou = false;
      const fim = (erro, valor) => {
        if (terminou) return;
        terminou = true;
        erro ? reject(erro) : resolve(valor);
      };
      // O método é uma constante: não há como este cliente enviar outra coisa.
      const req = http.request({ socketPath: socket, method: 'GET', path: alvoNormalizado(decisao), headers: { Host: 'docker' }, timeout: prazoMs }, (res) => {
        const partes = [];
        let total = 0;
        res.on('data', (parte) => {
          total += parte.length;
          if (total > limite) {
            req.destroy();
            fim(new ErroDocker('grande', 'resposta do Docker grande demais'));
            return;
          }
          partes.push(parte);
        });
        res.on('end', () => {
          if (res.statusCode !== 200) return fim(new ErroDocker('status', 'o Docker respondeu ' + res.statusCode));
          try {
            fim(null, filtrarResposta(decisao.caminho, JSON.parse(Buffer.concat(partes).toString('utf8'))));
          } catch (e) {
            fim(new ErroDocker('invalido', 'resposta do Docker não é JSON'));
          }
        });
        res.on('error', () => fim(new ErroDocker('indisponivel', 'conexão com o Docker interrompida')));
      });
      req.on('timeout', () => {
        req.destroy();
        fim(new ErroDocker('indisponivel', 'o Docker não respondeu a tempo'));
      });
      // sem o caminho do socket na mensagem: ela pode chegar a um log
      req.on('error', () => fim(new ErroDocker('indisponivel', 'não consegui falar com o Docker')));
      req.end();
    });
  }

  return {
    ler,
    info: () => ler('/info'),
    df: () => ler('/system/df'),
    containers: (todos = false) => ler('/containers/json' + (todos ? '?all=1' : ''))
  };
}

// Só a versão da API volta do Docker; o corpo e o tipo são os do filtro.
const CABECALHOS_REPASSADOS = ['api-version'];

/**
 * O proxy: um servidor num socket unix que só repassa o que `decidir` permite.
 * `socketReal` é o socket do Docker; `socketLocal` é onde o proxy escuta.
 * Devolve `{ servidor, ouvir(cb), fechar(cb) }`.
 */
function criarProxy(opcoes) {
  const socketReal = opcoes.socketReal || SOCKET_PADRAO;
  const socketLocal = opcoes.socketLocal;
  if (!socketLocal) throw new Error('socketLocal é obrigatório');
  const modo = opcoes.modo === undefined ? 0o660 : opcoes.modo; // quem fala com o socket precisa poder escrever nele
  const limite = opcoes.limite || LIMITE_RESPOSTA;
  const prazoMs = opcoes.prazoMs || PRAZO_MS;
  const registrar = opcoes.registrar || (() => {});

  const servidor = http.createServer({ maxHeaderSize: 8192, connectionsCheckingInterval: 1000 }, (req, res) => {
    let respondido = false;
    const responder = (status, obj, extras) => {
      if (respondido || res.headersSent) return;
      respondido = true;
      const corpo = JSON.stringify(obj);
      res.writeHead(status, Object.assign({ 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(corpo), 'Cache-Control': 'no-store' }, extras));
      res.end(corpo);
    };
    const corpoDeclarado = req.headers['transfer-encoding'] !== undefined || (req.headers['content-length'] !== undefined && req.headers['content-length'] !== '0');
    const decisao = decidir(req.method, req.url);
    if (!decisao.permitir || corpoDeclarado) {
      registrar('recusado ' + String(req.method).slice(0, 16));
      req.resume();
      return responder(decisao.permitir ? 400 : decisao.status, { message: 'Lab Desktop agente: ' + (decisao.permitir ? 'pedido com corpo não é permitido' : decisao.motivo) });
    }
    // Guarda a resposta inteira (com teto), filtra e só então responde: o que o filtro não conhece não sai daqui.
    const upstream = http.request({ socketPath: socketReal, method: decisao.metodo, path: alvoNormalizado(decisao), headers: { Host: 'docker' }, timeout: prazoMs }, (resposta) => {
      const partes = [];
      let total = 0;
      let estourou = false;
      resposta.on('data', (parte) => {
        total += parte.length;
        if (total > limite) {
          estourou = true;
          upstream.destroy();
          return;
        }
        partes.push(parte);
      });
      resposta.on('end', () => {
        if (estourou) return responder(502, { message: 'Lab Desktop agente: resposta do Docker grande demais' });
        if (resposta.statusCode !== 200) return responder(502, { message: 'Lab Desktop agente: o Docker respondeu ' + resposta.statusCode });
        let filtrada;
        try { filtrada = filtrarResposta(decisao.caminho, JSON.parse(Buffer.concat(partes).toString('utf8'))); } catch (e) {
          return responder(502, { message: 'Lab Desktop agente: resposta do Docker ilegível' });
        }
        const cabecalhos = {};
        for (const nome of CABECALHOS_REPASSADOS) {
          if (resposta.headers[nome] !== undefined) cabecalhos[nome] = resposta.headers[nome];
        }
        return responder(200, filtrada, cabecalhos);
      });
      resposta.on('error', () => responder(502, { message: 'Lab Desktop agente: conexão com o Docker interrompida' }));
    });
    upstream.on('timeout', () => upstream.destroy());
    upstream.on('error', () => responder(502, { message: 'Lab Desktop agente: o Docker não respondeu' }));
    upstream.end();
  });
  servidor.headersTimeout = 5000;
  servidor.requestTimeout = 10000;
  servidor.maxConnections = 32;
  // nada de upgrade nem túnel: derruba
  servidor.on('upgrade', (req, socket) => socket.destroy());
  servidor.on('connect', (req, socket) => socket.destroy());
  servidor.on('clientError', (erro, socket) => {
    // pedido que nem chega a ser HTTP válido: resposta curta e fecha (cabeçalho grande demais é 431)
    if (!socket.writable) return socket.destroy();
    const status = erro && erro.code === 'HPE_HEADER_OVERFLOW' ? '431 Request Header Fields Too Large' : '400 Bad Request';
    return socket.end('HTTP/1.1 ' + status + '\r\nConnection: close\r\nContent-Length: 0\r\n\r\n');
  });

  return {
    servidor,
    ouvir(cb) {
      try { fs.unlinkSync(socketLocal); } catch (e) { /* não existia */ }
      servidor.listen(socketLocal, () => {
        try { fs.chmodSync(socketLocal, modo); } catch (e) { /* o sistema de arquivos pode não deixar */ }
        if (cb) cb();
      });
    },
    fechar(cb) {
      servidor.close(() => {
        try { fs.unlinkSync(socketLocal); } catch (e) { /* já foi */ }
        if (cb) cb();
      });
      servidor.closeAllConnections();
    }
  };
}

function principal(argv) {
  const pegar = (nome) => {
    const i = argv.indexOf(nome);
    return i >= 0 ? argv[i + 1] : undefined;
  };
  const socketLocal = pegar('--ouvir');
  if (!socketLocal) {
    console.error('Uso: node docker-proxy.js --ouvir <socket de leitura> [--socket <socket do Docker>]');
    process.exit(2);
  }
  const { reduzirPrivilegios } = require('./privilegios.js');
  const socketReal = pegar('--socket') || process.env.PAINEL_DOCKER_SOCKET || SOCKET_PADRAO;
  // um proxy de leitura roda como usuário comum, com o grupo do socket do Docker (ver privilegios.js)
  // (uid 10002, diferente do uid do agente, 10001: um não lê o /proc/<pid>/environ nem os arquivos do outro)
  const r = reduzirPrivilegios({ usuarioPadrao: USUARIO_DO_PROXY, socketDocker: socketReal, pastas: [require('path').dirname(socketLocal)] });
  if (!r.ok) {
    console.error('[docker-proxy] ' + r.erro);
    process.exit(1);
  }
  // 0666: o diretório do socket (um volume só do proxy e do agente) é quem limita o acesso, e o proxy só repassa leituras filtradas
  const proxy = criarProxy({ socketReal, socketLocal, modo: 0o666, registrar: (t) => console.log('[docker-proxy] ' + t) });
  proxy.ouvir(() => console.log('[docker-proxy] só leitura em ' + socketLocal));
  for (const sinal of ['SIGTERM', 'SIGINT']) process.on(sinal, () => proxy.fechar(() => process.exit(0)));
}

if (require.main === module) principal(process.argv);

module.exports = { decidir, criarCliente, criarProxy, ErroDocker, REGRAS, SOCKET_PADRAO, LIMITE_RESPOSTA };
