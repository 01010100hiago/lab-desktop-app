'use strict';
/*
  privilegios.js: sai de root logo na partida.

  O `docker run` que o Lab Desktop usa não define usuário, então o processo nasce
  como root dentro do container. Root com `--pid host` alcança arquivos de outros
  processos da máquina por /proc/<pid>/root, e o agente não precisa de nada disso:
  ele lê /proc, /sys e o socket do Docker. Então, ainda como root, este módulo:

    1. cria a pasta de dados e a entrega ao usuário comum (por padrão uid 10001, gid 10001;
       o proxy de leitura usa 10002);
    2. entra no grupo proprietário do socket do Docker (é isso que dá acesso a ele, não ser root);
    3. troca para o usuário comum de forma definitiva (setgroups, setgid, setuid) e
       confere que não dá para voltar a root.

  Se qualquer passo falhar, devolve `{ ok: false }` e quem chamou NÃO continua:
  melhor não subir do que subir como root achando que não.

  Fora de root (rodando como usuário comum, ou no Windows) não faz nada.
  PAINEL_USUARIO=root mantém root de propósito (uma linha de aviso no log).
*/
const fs = require('fs');
const path = require('path');

// uid alto e sem uso em máquina nenhuma: o uid 1000 costuma ser o do administrador, e um processo com o mesmo uid lê os
// arquivos 0600 dele (com a raiz montada) e o environ dos processos dele (com pid: host).
const USUARIO_DO_AGENTE = '10001:10001';
const NOME_RE = /^[a-z_][a-z0-9_-]{0,31}$/;
const NUMERO_RE = /^([0-9]{1,9})(?::([0-9]{1,9}))?$/;

// nome (procurado no passwd), "10001" ou "10001:10001" -> { uid, gid } ou null
function resolverUsuario(texto, conteudoDoPasswd) {
  const m = NUMERO_RE.exec(texto);
  if (m) return { uid: Number(m[1]), gid: Number(m[2] === undefined ? m[1] : m[2]) };
  if (!NOME_RE.test(texto)) return null;
  for (const linha of String(conteudoDoPasswd).split('\n')) {
    const c = linha.split(':');
    if (c.length >= 4 && c[0] === texto && /^[0-9]+$/.test(c[2]) && /^[0-9]+$/.test(c[3])) return { uid: Number(c[2]), gid: Number(c[3]) };
  }
  return null;
}

// entrega a pasta (e os arquivos comuns dentro dela, sem seguir link simbólico e sem descer em subpasta) ao usuário
function entregarPasta(pasta, uid, gid, fsMod) {
  fsMod.mkdirSync(pasta, { recursive: true, mode: 0o700 });
  fsMod.chownSync(pasta, uid, gid);
  for (const nome of fsMod.readdirSync(pasta)) {
    const alvo = path.join(pasta, nome);
    const st = fsMod.lstatSync(alvo);
    if (st.isFile() && (st.uid !== uid || st.gid !== gid)) fsMod.lchownSync(alvo, uid, gid);
  }
}

/**
 * opcoes: usuario, socketDocker, pastas[], e para teste: proc, fsMod, passwd (texto do /etc/passwd).
 * Devolve { ok: true, mudou, uid?, gid?, aviso? } ou { ok: false, erro }.
 */
function reduzirPrivilegios(opcoes = {}) {
  const proc = opcoes.proc || process;
  const fsMod = opcoes.fsMod || fs;
  const usuario = String(opcoes.usuario || process.env.PAINEL_USUARIO || opcoes.usuarioPadrao || USUARIO_DO_AGENTE).trim();
  if (typeof proc.getuid !== 'function' || proc.getuid() !== 0) return { ok: true, mudou: false };
  if (usuario === 'root' || usuario === '0') return { ok: true, mudou: false, aviso: 'executando como root (PAINEL_USUARIO=' + usuario + ')' };

  let passwd = opcoes.passwd;
  if (passwd === undefined) {
    try { passwd = fsMod.readFileSync('/etc/passwd', 'utf8'); } catch (e) { passwd = ''; }
  }
  const alvo = resolverUsuario(usuario, passwd);
  if (!alvo || alvo.uid === 0) return { ok: false, erro: 'PAINEL_USUARIO inválido ou desconhecido: use um usuário comum (por exemplo 10001:10001).' };

  try {
    for (const pasta of opcoes.pastas || []) entregarPasta(pasta, alvo.uid, alvo.gid, fsMod);
    const grupos = [alvo.gid];
    if (opcoes.socketDocker) {
      try {
        const gidDoSocket = fsMod.statSync(opcoes.socketDocker).gid;
        if (!grupos.includes(gidDoSocket)) grupos.push(gidDoSocket);
      } catch (e) { /* o Docker ainda não subiu: o agente segue sem ele e mostra "sem leitura" */ }
    }
    proc.setgroups(grupos);
    proc.setgid(alvo.gid);
    proc.setuid(alvo.uid);
  } catch (e) {
    return { ok: false, erro: 'não consegui trocar para o usuário comum (' + (e && e.code ? e.code : 'erro') + ')' };
  }
  if (proc.getuid() !== alvo.uid || proc.geteuid() !== alvo.uid) return { ok: false, erro: 'a troca de usuário não valeu' };
  // a troca precisa ser definitiva: voltar a root tem que falhar
  let voltou = false;
  try { proc.setuid(0); voltou = true; } catch (e) { /* o esperado */ }
  if (voltou) return { ok: false, erro: 'o processo ainda consegue voltar a root' };
  const aviso = alvo.uid < 10000 ? 'o uid ' + alvo.uid + ' é baixo e pode ser o de um usuário da máquina (leria os arquivos 0600 e o environ dele): prefira 10001 ou mais' : undefined;
  return aviso ? { ok: true, mudou: true, uid: alvo.uid, gid: alvo.gid, aviso } : { ok: true, mudou: true, uid: alvo.uid, gid: alvo.gid };
}

module.exports = { reduzirPrivilegios, resolverUsuario, USUARIO_DO_AGENTE };
