'use strict';
/*
  metricas.js: lê o estado da máquina (CPU, memória, disco, rede, temperatura, processos,
  containers) e monta as respostas de /api/servidor e /api/servidor/detalhe.

  De onde vem cada coisa (tudo SÓ LEITURA):
    /proc          CPU, memória, carga, rede, disco escrito, processos (o container precisa de `--pid host`
                   para enxergar a máquina inteira e não só ele mesmo)
    /sys           temperaturas, bateria e tomada, identificação da placa (DMI)
    /host/etc/...  nome da máquina, sistema, nomes de usuário (arquivos da máquina, montados só leitura)
    Docker         só /info, /system/df e /containers/json, pelo filtro de leitura (docker-proxy.js)
  Nenhuma linha de comando é executada: nem `docker`, nem shell, nem qualquer outro programa.

  CPU e rede são taxas: só fazem sentido entre duas leituras. Por isso UM amostrador
  (a cada 2 s) lê /proc/stat e /proc/net/dev e guarda o resultado; as rotas só leem esse
  resultado, nunca recalculam (duas chamadas quase juntas dariam um intervalo de poucos
  milissegundos e o contador do kernel, que anda de 10 em 10 ms, viraria 0 % ou 100 %).

  Tudo que toca em disco ou no Docker é parametrizado (`procDir`, `sysDir`, `hostDir`, `docker`),
  para os testes usarem pastas de mentira.
*/
const fs = require('fs');
const os = require('os');
const path = require('path');
const historicoMetricas = require('./historico.js');

const CLK_TCK = 100; // jiffies por segundo: o padrão de praticamente todo kernel Linux
const MAXIMO_DE_PROCESSOS_LIDOS = 30000;
const PROCESSOS_NA_RESPOSTA = 20;
const LOTE_DE_PROCESSOS = 64;
const DF_INTERVALO_MS = 10 * 60 * 1000;
const NOME_DO_PROCESSO_MAX = 64;

/* ---------- funções puras (testadas sem disco) ---------- */

// Texto de /proc/stat -> { cpu: {total, ocioso}, cpu0: ..., ... }
function lerCpuBruta(texto) {
  const atuais = {};
  for (const l of String(texto).split('\n')) {
    const m = l.match(/^(cpu\d*)\s+(.*)$/);
    if (!m) continue;
    const vals = m[2].trim().split(/\s+/).map(Number);
    if (vals.some((v) => !Number.isFinite(v))) continue;
    atuais[m[1]] = { total: vals.reduce((a, b) => a + b, 0), ocioso: (vals[3] || 0) + (vals[4] || 0) };
  }
  return atuais;
}

// Uso (0..1) de UMA linha de /proc/stat entre duas leituras (contadores sempre crescentes).
function calcularUsoCpu(anterior, atual) {
  if (!anterior || !atual) return null;
  const deltaTotal = atual.total - anterior.total;
  if (deltaTotal <= 0) return null; // o relógio voltou ou a leitura se repetiu
  const uso = 1 - (atual.ocioso - anterior.ocioso) / deltaTotal;
  return Math.max(0, Math.min(1, uso));
}

// Texto de /proc/net/dev -> { interface: {rx, tx} } sem o loopback e sem as interfaces virtuais do Docker
// (senão o próprio tráfego dos containers domina o gráfico).
function lerRedeBruta(texto) {
  const atuais = {};
  for (const l of String(texto).split('\n').slice(2)) {
    const m = l.trim().match(/^([^:]+):\s*(.*)$/);
    if (!m) continue;
    const nome = m[1].trim();
    if (/^(lo|docker|veth|br-)/.test(nome)) continue;
    const campos = m[2].trim().split(/\s+/).map(Number);
    atuais[nome] = { rx: campos[0] || 0, tx: campos[8] || 0 };
  }
  return atuais;
}

// Bytes por segundo; null se o intervalo é zero ou negativo ou se o contador reiniciou (interface recriada).
function calcularBps(deltaBytes, deltaSegundos) {
  if (!(deltaSegundos > 0) || deltaBytes < 0) return null;
  return deltaBytes / deltaSegundos;
}

// A interface com mais tráfego (rx + tx) entre duas leituras.
function calcularMelhorInterface(anterior, atual, deltaSegundos) {
  let melhor = null;
  let melhorTrafego = -1;
  for (const nome of Object.keys(atual)) {
    const ant = anterior[nome];
    if (!ant) continue;
    const rx = calcularBps(atual[nome].rx - ant.rx, deltaSegundos);
    const tx = calcularBps(atual[nome].tx - ant.tx, deltaSegundos);
    if (rx === null || tx === null) continue;
    if (rx + tx > melhorTrafego) {
      melhorTrafego = rx + tx;
      melhor = { nome, rx, tx };
    }
  }
  return melhor;
}

function calcularCpuPercentual(deltaJiffies, deltaSegundos) {
  if (!(deltaSegundos > 0)) return null;
  return Math.max(0, deltaJiffies / CLK_TCK / deltaSegundos * 100);
}

function lerMemoriaDoTexto(texto) {
  const mem = {};
  for (const l of String(texto).split('\n')) {
    const m = l.match(/^(\w+):\s+(\d+)/);
    if (m) mem[m[1]] = parseInt(m[2], 10) * 1024;
  }
  const total = mem.MemTotal || 0;
  const disponivel = mem.MemAvailable || 0;
  return {
    total,
    usada: total - disponivel,
    disponivel,
    livre: mem.MemFree || 0,
    cache: mem.Cached || 0,
    buffers: mem.Buffers || 0,
    swap: { total: mem.SwapTotal || 0, usada: (mem.SwapTotal || 0) - (mem.SwapFree || 0) }
  };
}

// O id do container (12 a 64 hexadecimais) dentro de um /proc/<pid>/cgroup, ou null.
function idDeContainerDoCgroup(texto) {
  const m = String(texto).match(/docker-([0-9a-f]{12,64})\.scope/) || String(texto).match(/\/docker\/([0-9a-f]{12,64})/);
  return m ? m[1] : null;
}

function tamanhoOuZero(v) {
  return typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : 0;
}

// Resposta de GET /system/df -> { tamanhos, volumes }. Aceita o formato novo (`ImageUsage`,
// `VolumeUsage`...) e o antigo (`LayersSize`, listas com os tamanhos).
function resumirDf(df) {
  if (!df || typeof df !== 'object') return null;
  const lista = (v) => (Array.isArray(v) ? v : []);
  const soma = (itens, campo) => itens.reduce((a, x) => a + tamanhoOuZero(x && (campo(x))), 0);
  const tamanhos = {
    imagens: df.ImageUsage ? tamanhoOuZero(df.ImageUsage.TotalSize) : tamanhoOuZero(df.LayersSize),
    containers: df.ContainerUsage ? tamanhoOuZero(df.ContainerUsage.TotalSize) : soma(lista(df.Containers), (x) => x.SizeRw),
    volumes: df.VolumeUsage ? tamanhoOuZero(df.VolumeUsage.TotalSize) : soma(lista(df.Volumes), (x) => x.UsageData && x.UsageData.Size),
    cache: df.BuildCacheUsage ? tamanhoOuZero(df.BuildCacheUsage.TotalSize) : soma(lista(df.BuildCache), (x) => x.Size)
  };
  const volumes = df.VolumeUsage && Number.isFinite(df.VolumeUsage.TotalCount) ? df.VolumeUsage.TotalCount : lista(df.Volumes).length;
  return { tamanhos, volumes };
}

function limpar(txt, maximo) {
  return String(txt).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, maximo);
}

/* ---------- a fábrica ---------- */

/*
  opcoes: docker ({ info(), df(), containers() }, promessas), gravador (historico.js), e para teste
  procDir, sysDir, hostDir, relogio.
*/
function criarMetricas(opcoes = {}) {
  const docker = opcoes.docker || null;
  const gravador = opcoes.gravador || null;
  const procDir = opcoes.procDir || '/proc';
  const sysDir = opcoes.sysDir || '/sys';
  const hostDir = opcoes.hostDir || '/host';
  const relogio = opcoes.relogio || Date.now;
  const avisar = opcoes.avisar || ((t) => console.error('[metricas] ' + t));

  const lerArquivo = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; } };
  const lerProc = (nome) => lerArquivo(path.join(procDir, nome));
  const sysNum = (arquivo) => { const v = parseInt(lerArquivo(arquivo), 10); return Number.isNaN(v) ? null : v; };
  const sysTexto = (arquivo) => lerArquivo(arquivo).trim() || null;

  /* ----- identidade ----- */
  const lerHostname = () => lerArquivo(path.join(hostDir, 'etc/hostname')).trim() || os.hostname();
  function lerSistema() {
    const m = lerArquivo(path.join(hostDir, 'etc/os-release')).match(/^PRETTY_NAME="?([^"\n]+)"?/m);
    return m ? m[1] : os.type();
  }
  function lerModeloCpu() {
    const m = lerProc('cpuinfo').match(/^model name\s*:\s*(.+)$/m);
    if (m) return m[1].trim();
    const c = os.cpus();
    return (c[0] && c[0].model) || null;
  }
  function lerTemperatura() {
    let max = null;
    for (let i = 0; i < 10; i++) {
      const v = parseInt(lerArquivo(path.join(sysDir, 'class/thermal/thermal_zone' + i + '/temp')), 10);
      if (!Number.isNaN(v) && v > 0 && v < 150000) max = Math.max(max || 0, v / 1000);
    }
    return max;
  }
  const lerMemoria = () => lerMemoriaDoTexto(lerProc('meminfo'));

  /* ----- o amostrador único de CPU, rede e escrita no disco ----- */
  let ultimaAmostra = null;
  let anteriorBruta = null;
  let cpuRecentes = [];
  let paraHistorico = [];
  let historicoCurto = { passo_s: 10, cpu: [], mem: [], rx_bps: [], tx_bps: [], temp: [] }; // 60 pontos de 10 s (10 min)

  function amostrar() {
    const agora = relogio();
    const cpuBruta = lerCpuBruta(lerProc('stat'));
    const redeBruta = lerRedeBruta(lerProc('net/dev'));
    const setoresEscritos = historicoMetricas.lerSetoresEscritos(lerProc('diskstats')); // null fora do Linux
    let uso = null;
    let porNucleo = [];
    let rede = { interface: null, rx_bps: 0, tx_bps: 0 };
    let escritaBps = null;
    let rx = null; // null = não houve medida (semente, sem delta ou sem interface): nunca zero, que viraria uma queda falsa
    let tx = null;
    if (anteriorBruta) {
      const deltaS = (agora - anteriorBruta.quando) / 1000; // tempo real decorrido, não os 2 s nominais
      uso = calcularUsoCpu(anteriorBruta.cpu.cpu, cpuBruta.cpu);
      porNucleo = [];
      for (let i = 0; cpuBruta['cpu' + i]; i++) porNucleo.push(calcularUsoCpu(anteriorBruta.cpu['cpu' + i], cpuBruta['cpu' + i]));
      const melhor = calcularMelhorInterface(anteriorBruta.rede, redeBruta, deltaS);
      if (melhor) {
        rede = { interface: limpar(melhor.nome, 32), rx_bps: Math.round(melhor.rx), tx_bps: Math.round(melhor.tx) };
        rx = rede.rx_bps;
        tx = rede.tx_bps;
      }
      if (setoresEscritos !== null && anteriorBruta.setoresEscritos !== null) {
        const bps = calcularBps((setoresEscritos - anteriorBruta.setoresEscritos) * 512, deltaS);
        escritaBps = bps === null ? null : Math.round(bps);
      }
    }
    anteriorBruta = { quando: agora, cpu: cpuBruta, rede: redeBruta, setoresEscritos };
    cpuRecentes.push(uso);
    if (cpuRecentes.length > 5) cpuRecentes.shift();
    const validos = cpuRecentes.filter((v) => v !== null);
    const media = validos.length ? validos.reduce((a, b) => a + b, 0) / validos.length : null;
    ultimaAmostra = { quando: agora, cpu: { instantaneo: uso, media, porNucleo }, rede };
    paraHistorico.push({ cpu: uso, rx_bps: rx, tx_bps: tx, esc_bps: escritaBps });
    if (paraHistorico.length > 60) paraHistorico.shift(); // teto de memória se o passo de 10 s atrasar
  }

  const mediaCampo = (amostras, campo) => {
    const vals = amostras.map((a) => a[campo]).filter((v) => v !== null);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  };
  const maximoCampo = (amostras, campo) => {
    const vals = amostras.map((a) => a[campo]).filter((v) => v !== null);
    return vals.length ? Math.max(...vals) : null;
  };

  // A cada 10 s: um ponto no anel de 10 min (os sparklines) e uma amostra para o gravador de longo prazo.
  async function amostrarHistorico() {
    const mem = lerMemoria();
    const cpuMedia = mediaCampo(paraHistorico, 'cpu');
    const rxMedia = mediaCampo(paraHistorico, 'rx_bps');
    const txMedia = mediaCampo(paraHistorico, 'tx_bps');
    const escMedia = mediaCampo(paraHistorico, 'esc_bps');
    const cpuMax = maximoCampo(paraHistorico, 'cpu');
    const escMax = maximoCampo(paraHistorico, 'esc_bps');
    paraHistorico = []; // começa nova janela de 10 s
    const empurrar = (arr, v) => { arr.push(v); if (arr.length > 60) arr.shift(); };
    const usoMem = mem.total ? mem.usada / mem.total : null;
    empurrar(historicoCurto.cpu, cpuMedia);
    empurrar(historicoCurto.mem, usoMem);
    empurrar(historicoCurto.rx_bps, rxMedia !== null ? Math.round(rxMedia) : 0);
    empurrar(historicoCurto.tx_bps, txMedia !== null ? Math.round(txMedia) : 0);
    empurrar(historicoCurto.temp, lerTemperatura());
    if (!gravador) return;
    // o uso do disco principal é a mesma conta de /api/servidor (usado / total do primeiro disco)
    const discos = await lerDiscos();
    const d = discos[0];
    gravador.registrar({
      cpu: cpuMedia, cpuMax, mem: usoMem, disco: d && d.total ? d.usado / d.total : null,
      esc: escMedia, escMax, rx: rxMedia, tx: txMedia
    });
  }

  /* ----- discos ----- */
  function statfsBytes(caminho) {
    return new Promise((resolve) => {
      if (!fs.statfs) return resolve(null);
      return fs.statfs(caminho, (err, st) => {
        if (err) return resolve(null);
        return resolve({ total: st.blocks * st.bsize, usado: (st.blocks - st.bfree) * st.bsize, livre: st.bavail * st.bsize });
      });
    });
  }
  // O disco da máquina (não o do container): o statfs de um arquivo da máquina montado dentro do container
  // responde pelo sistema de arquivos de origem. Se só o diretório existir, usa ele.
  async function lerDiscos() {
    const sondas = [path.join(hostDir, 'etc/os-release'), path.join(hostDir, 'etc/hostname'), hostDir];
    for (const s of sondas) {
      const r = await statfsBytes(s);
      if (r) return [Object.assign({ montagem: '/' }, r)];
    }
    return [];
  }

  /* ----- processos ----- */
  let passwdCache = null;
  function nomeUsuario(uid) {
    if (!passwdCache) {
      passwdCache = {};
      for (const l of lerArquivo(path.join(hostDir, 'etc/passwd')).split('\n')) {
        const p = l.split(':');
        if (p.length >= 3) passwdCache[p[2]] = p[0];
      }
    }
    return limpar(passwdCache[uid] || String(uid), 32);
  }

  async function mapaDeContainers() {
    const mapa = {};
    if (!docker) return mapa;
    try {
      for (const c of await docker.containers()) {
        if (c && typeof c.Id === 'string' && Array.isArray(c.Names) && c.Names[0]) mapa[c.Id] = limpar(String(c.Names[0]).replace(/^\//, ''), 128);
      }
    } catch (e) { /* sem Docker: os processos ficam sem nome de container */ }
    return mapa;
  }
  function containerDoCgroup(texto, mapaIds) {
    const id = idDeContainerDoCgroup(texto);
    if (!id) return null;
    const chave = Object.keys(mapaIds).find((k) => k.startsWith(id) || id.startsWith(k));
    return chave ? mapaIds[chave] : null;
  }

  let procAnterior = new Map();
  let procCache = { quando: 0, dados: null, esperando: null };

  async function lerUmProcesso(pid, agora, mapaIds, novos) {
    try {
      const [stat, status, cgroup] = await Promise.all([
        fs.promises.readFile(path.join(procDir, pid, 'stat'), 'utf8'),
        fs.promises.readFile(path.join(procDir, pid, 'status'), 'utf8'),
        fs.promises.readFile(path.join(procDir, pid, 'cgroup'), 'utf8').catch(() => '')
      ]);
      const fim = stat.lastIndexOf(')');
      if (fim === -1) return null;
      const nome = stat.slice(stat.indexOf('(') + 1, fim);
      const resto = stat.slice(fim + 2).split(' ');
      const jiffies = (parseInt(resto[11], 10) || 0) + (parseInt(resto[12], 10) || 0);
      const mUid = status.match(/^Uid:\s*(\d+)/m);
      const mRss = status.match(/^VmRSS:\s*(\d+)/m);
      const ant = procAnterior.get(pid);
      const cpu = ant ? calcularCpuPercentual(jiffies - ant.jiffies, (agora - ant.quando) / 1000) : null;
      novos.set(pid, { jiffies, quando: agora });
      return {
        pid: parseInt(pid, 10),
        nome: limpar(nome, NOME_DO_PROCESSO_MAX),
        usuario: mUid ? nomeUsuario(parseInt(mUid[1], 10)) : null,
        cpu,
        mem: mRss ? parseInt(mRss[1], 10) * 1024 : 0,
        container: containerDoCgroup(cgroup, mapaIds)
      };
    } catch (e) {
      return null; // o processo pode ter morrido entre o readdir e a leitura
    }
  }

  async function varrerProcessos() {
    const mapaIds = await mapaDeContainers();
    let pids;
    try { pids = (await fs.promises.readdir(procDir)).filter((n) => /^[0-9]{1,10}$/.test(n)).slice(0, MAXIMO_DE_PROCESSOS_LIDOS); } catch (e) { return []; }
    const agora = relogio();
    const novos = new Map();
    const lidos = [];
    for (let i = 0; i < pids.length; i += LOTE_DE_PROCESSOS) {
      const lote = await Promise.all(pids.slice(i, i + LOTE_DE_PROCESSOS).map((pid) => lerUmProcesso(pid, agora, mapaIds, novos)));
      for (const p of lote) if (p) lidos.push(p);
    }
    procAnterior = novos; // quem morreu sai da tabela
    lidos.sort((a, b) => (b.cpu || 0) - (a.cpu || 0) || b.mem - a.mem);
    return lidos.slice(0, PROCESSOS_NA_RESPOSTA);
  }

  // Varrer /proc inteiro custa: cache de 5 s e uma varredura por vez (quem chega no meio espera a mesma).
  function listarProcessos() {
    if (procCache.dados && relogio() - procCache.quando < 5000) return Promise.resolve(procCache.dados);
    if (procCache.esperando) return procCache.esperando;
    const espera = varrerProcessos().then((lista) => {
      procCache = { quando: relogio(), dados: lista, esperando: null };
      return lista;
    }, () => {
      procCache = { quando: 0, dados: null, esperando: null };
      return [];
    });
    procCache.esperando = espera;
    return espera;
  }

  /* ----- Docker (info a cada 60 s; df a cada 10 min, em segundo plano) ----- */
  let infoCache = { quando: 0, dados: null };
  async function infoDocker() {
    if (!docker) return null;
    if (relogio() - infoCache.quando < 60000 && infoCache.dados) return infoCache.dados;
    try {
      const i = await docker.info();
      const n = (v) => (Number.isFinite(v) && v >= 0 ? v : 0);
      infoCache = { quando: relogio(), dados: {
        versao: limpar(i.ServerVersion || '', 40), rodando: n(i.ContainersRunning), pausados: n(i.ContainersPaused),
        parados: n(i.ContainersStopped), containers: n(i.Containers), imagens: n(i.Images)
      } };
    } catch (e) {
      infoCache = { quando: relogio(), dados: null };
    }
    return infoCache.dados;
  }

  // `system df` mede o tamanho de todos os volumes: é caro no daemon. No máximo a cada 10 min, sempre em
  // segundo plano (quem pede recebe o último valor na hora), uma execução por vez.
  let dfCache = { quando: 0, dados: null, rodando: false };
  function atualizarDf() {
    if (!docker || dfCache.rodando) return;
    dfCache.rodando = true;
    docker.df().then((df) => {
      dfCache = { quando: relogio(), dados: resumirDf(df), rodando: false };
    }, () => {
      dfCache = { quando: relogio(), dados: dfCache.dados, rodando: false }; // não insistir em laço se falhar
    });
  }
  function infoDf() {
    if (relogio() - dfCache.quando >= DF_INTERVALO_MS) atualizarDf();
    return dfCache.dados; // pode ser null logo depois de subir
  }
  async function infoDockerCompleto() {
    const info = await infoDocker();
    if (!info) return null;
    const df = infoDf();
    return Object.assign({}, info, {
      volumes: (df && df.volumes) || 0,
      tamanhos: (df && df.tamanhos) || { imagens: 0, containers: 0, volumes: 0, cache: 0 }
    });
  }

  /* ----- as respostas ----- */
  // Forma de /api/servidor (CONTRATO-API 3.2). `sessoes` e `imagemSessao` existem por compatibilidade
  // com o app e ficam sempre vazios: este agente não abre sessões.
  async function infoServidor(opts = {}) {
    const amostra = ultimaAmostra || { cpu: { instantaneo: null, media: null, porNucleo: [] }, rede: { interface: null, rx_bps: 0, tx_bps: 0 } };
    const obj = {
      quando: new Date(relogio()).toISOString(),
      hostname: limpar(lerHostname(), 128),
      sistema: limpar(lerSistema(), 128),
      kernel: limpar(os.release(), 128),
      uptime: parseFloat(lerProc('uptime').split(' ')[0]) || 0,
      carga: lerProc('loadavg').split(' ').slice(0, 3).map(Number).map((v) => (Number.isFinite(v) ? v : 0)),
      cpu: {
        // "uso" é o valor mostrado: suavizado, média das últimas 5 amostras de 2 s (10 s).
        // "usoInstantaneo" é a leitura mais recente, sem suavizar.
        uso: amostra.cpu.media !== null ? amostra.cpu.media : amostra.cpu.instantaneo,
        usoInstantaneo: amostra.cpu.instantaneo,
        porNucleo: amostra.cpu.porNucleo,
        nucleos: os.cpus().length,
        modelo: limpar(lerModeloCpu() || '', 128) || null,
        temperatura: lerTemperatura()
      },
      memoria: lerMemoria(),
      rede: amostra.rede,
      node: { painel: process.version, imagemSessao: null }
    };
    if (opts.comHistorico) obj.historico = historicoCurto;
    obj.discos = await lerDiscos();
    obj.docker = await infoDockerCompleto();
    obj.sessoes = [];
    if (opts.comProcessos) obj.processos = await listarProcessos();
    return obj;
  }

  /* sensores hwmon (coretemp, acpitz, amdgpu...): cada temp*_input em miligraus; rótulo em temp*_label; limites em _max/_crit */
  function lerSensores() {
    const base = path.join(sysDir, 'class/hwmon');
    const saida = [];
    let dirs;
    try { dirs = fs.readdirSync(base); } catch (e) { return saida; }
    for (const d of dirs.sort()) {
      const dir = path.join(base, d);
      const chip = sysTexto(path.join(dir, 'name')) || d;
      let arquivos;
      try { arquivos = fs.readdirSync(dir); } catch (e) { continue; }
      const entradas = arquivos.filter((f) => /^temp\d+_input$/.test(f)).sort((a, b) => parseInt(a.slice(4), 10) - parseInt(b.slice(4), 10));
      for (const f of entradas) {
        const pre = path.join(dir, f.replace('_input', ''));
        const v = sysNum(path.join(dir, f));
        if (v === null || v <= 0 || v > 150000) continue;
        const max = sysNum(pre + '_max');
        const crit = sysNum(pre + '_crit');
        saida.push({
          chip: limpar(chip, 64), rotulo: limpar(sysTexto(pre + '_label') || chip, 64), c: v / 1000,
          max: max !== null && max > 0 ? max / 1000 : null, crit: crit !== null && crit > 0 ? crit / 1000 : null
        });
      }
    }
    return saida;
  }

  // Tomada ou bateria (um laptop que perde a energia continua rodando na bateria).
  function lerEnergia() {
    const base = path.join(sysDir, 'class/power_supply');
    const saida = { tomada: null, baterias: [] };
    let dirs;
    try { dirs = fs.readdirSync(base); } catch (e) { return saida; }
    for (const d of dirs) {
      const dir = path.join(base, d);
      const tipo = sysTexto(path.join(dir, 'type'));
      if (tipo === 'Mains') {
        const on = sysNum(path.join(dir, 'online'));
        if (on !== null) saida.tomada = saida.tomada || on === 1;
      }
      if (tipo === 'Battery') {
        const cheio = sysNum(path.join(dir, 'energy_full')) || sysNum(path.join(dir, 'charge_full'));
        const projeto = sysNum(path.join(dir, 'energy_full_design')) || sysNum(path.join(dir, 'charge_full_design'));
        saida.baterias.push({
          nome: limpar(d, 32), carga: sysNum(path.join(dir, 'capacity')), estado: sysTexto(path.join(dir, 'status')),
          saude: cheio && projeto ? cheio / projeto : null
        });
      }
    }
    return saida;
  }

  function lerMaquina() {
    const dmi = path.join(sysDir, 'class/dmi/id');
    const t = (arq) => { const v = sysTexto(path.join(dmi, arq)); return v === null ? null : limpar(v, 128); };
    return {
      fabricante: t('sys_vendor'), modelo: t('product_name'), versao: t('product_version'),
      placa: t('board_name'), bios: t('bios_version'), biosData: t('bios_date'),
      cpuModelo: limpar(lerModeloCpu() || '', 128) || null, nucleos: os.cpus().length,
      memoriaTotal: lerMemoria().total, arquitetura: os.arch()
    };
  }

  // Forma de /api/servidor/detalhe (CONTRATO-API 3.3): tudo de /api/servidor mais sensores, energia e máquina.
  // Sem projetos, `consumo` é sempre vazio; um processo de container fica sem projeto e um processo da máquina é "(servidor)".
  async function detalhe() {
    const srv = await infoServidor({ comProcessos: true, comHistorico: true });
    srv.sensores = lerSensores();
    srv.energia = lerEnergia();
    srv.maquina = lerMaquina();
    srv.consumo = [];
    for (const p of srv.processos || []) p.projeto = p.container ? null : '(servidor)';
    return srv;
  }

  /* ----- ciclo de vida ----- */
  let temporizadores = [];
  function iniciar() {
    amostrar(); // a primeira leitura só semeia: sem "anterior" ainda não há delta
    const agendar = (fn, ms) => {
      const t = setInterval(() => {
        try {
          const r = fn();
          if (r && typeof r.catch === 'function') r.catch(() => avisar('uma leitura falhou'));
        } catch (e) { avisar('uma leitura falhou'); }
      }, ms);
      t.unref();
      temporizadores.push(t);
    };
    agendar(amostrar, 2000);
    agendar(amostrarHistorico, 10000);
    const primeira = setTimeout(() => { amostrarHistorico().catch(() => {}); }, 4000); // espera uma amostra de 2 s com delta pronto
    primeira.unref();
    temporizadores.push(primeira);
    if (gravador) {
      // vai ao disco a cada 5 minutos (só se mudou) e ao encerrar: no máximo 5 minutos se perdem numa queda
      agendar(() => { if (gravador.suja()) gravador.salvar(); }, 300000);
    }
    const df = setTimeout(atualizarDf, 20000); // primeira leitura do `system df`, depois de o agente assentar
    df.unref();
    temporizadores.push(df);
  }
  function parar() {
    for (const t of temporizadores) { clearInterval(t); clearTimeout(t); }
    temporizadores = [];
    if (gravador && gravador.suja()) gravador.salvar();
  }

  return {
    iniciar, parar, infoServidor, detalhe,
    // para teste
    _amostrar: amostrar, _amostrarHistorico: amostrarHistorico, _atualizarDf: atualizarDf, _lerDiscos: lerDiscos
  };
}

module.exports = {
  criarMetricas,
  lerCpuBruta, calcularUsoCpu, lerRedeBruta, calcularBps, calcularMelhorInterface, calcularCpuPercentual,
  lerMemoriaDoTexto, idDeContainerDoCgroup, resumirDf
};
