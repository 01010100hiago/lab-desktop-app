'use strict';
/*
  Histórico de métricas do servidor (CPU, memória, disco, escrita no disco, rede), gravado pelo próprio agente para
  funcionar com o Lab Desktop fechado. Node puro, sem dependência.

  Resolução decrescente, por BALDE (a média das amostras de 10 s que caem nele; CPU e escrita guardam também o MÁXIMO):

      faixa  balde   guarda      pontos
      10s    10 s    1 hora      360
      1m     1 min   1 dia       1440
      10m    10 min  1 semana    1008
      1h     1 h     1 mês       720          (mais uma folga de 2 por faixa)

  Cada balde fechado vira UM ponto `[t, cpu, cpuMax, mem, disco, esc, escMax, rx, tx, nCpu, nMem, nDisco, nEsc, nRx, nTx]` (t = início do
  balde, segundos desde 1970; valor que não houve = null; os 6 últimos são QUANTAS amostras entraram em cada média: é o peso do balde na
  média da célula de uma consulta, então um balde fechado com poucas amostras, por exemplo o agente que ficou parado, não pesa como um cheio).
  Ponto antigo, só com os 9 primeiros campos, ainda é lido e pesa o nominal (passo / 10 s). O balde ABERTO (o de agora) também é guardado, com as somas e as contagens, para que um
  reinício do agente não perca até uma hora da faixa de 1 h.

  Arquivo (JSON compacto, uma linha só):
      {"v":1,"u":<último t gravado>,"f":{"10s":{"p":[[...],...],"a":{"i":<índice do balde>,"s":[6 somas],"c":[6 contagens],"m":[cpuMax,escMax]}},...}}
  Gravação ATÔMICA (arquivo temporário ao lado + fsync + rename): quem lê vê o arquivo antigo ou o novo, nunca um pedaço. Se o
  arquivo não presta (JSON quebrado, versão desconhecida, grande demais) ele é guardado como `<arquivo>.corrompido` e o
  gravador começa vazio; uma faixa estragada começa vazia sem derrubar as outras. Se o disco não deixa gravar, o agente segue
  só em memória (uma frase no log, só na mudança).

  Relógio (nunca apagar histórico por causa de UMA leitura de hora errada): uma amostra até 1 hora ANTES da última gravada é só
  ignorada. Um SALTO maior (para trás, mais de 1 hora; ou para frente, mais de 1 hora) entra em QUARENTENA: nada é gravado, podado nem
  descartado enquanto não houver amostras SEGUIDAS e coerentes no relógio novo (para frente: 6 amostras, cerca de 1 minuto; para trás:
  1 hora inteira, porque o que "está no futuro" só é descartado quando se tem certeza de que o relógio de antes é que estava errado). Se a
  hora volta ao normal no meio da quarentena (o NTP acertou o relógio), a quarentena acaba e o histórico fica intacto. Também não há
  poda por idade: cada faixa só é limitada pela capacidade (o que está fora da janela não aparece na consulta de qualquer jeito), então
  uma amostra à frente nunca leva o passado embora.

  A resposta de `consultar` é uma GRADE regular (um valor por célula, null onde não há dado), com no máximo 300 pontos.
*/
const fs = require('fs');
const path = require('path');

const VERSAO_ARQUIVO = 1;
const LIMITE_DO_ARQUIVO = 4 * 1024 * 1024; /* maior arquivo aceito na leitura */
const LIMITE_PARA_PODAR = 2 * 1024 * 1024; /* acima disto, ao gravar, as faixas são enxugadas (nunca acontece com as capacidades de hoje) */
const RECUO_TOLERADO_S = 3600;
const SALTO_PARA_FRENTE_S = 3600; /* mais que isto à frente da última amostra boa é salto de relógio (ou o agente ficou parado muito tempo) */
const AMOSTRAS_PARA_ACEITAR_SALTO = 6; /* salto para frente: amostras seguidas e coerentes (10 s cada) antes de aceitar */
const QUARENTENA_DE_RECUO_S = 3600; /* salto para trás: tempo seguido e coerente no relógio novo antes de descartar o "futuro" */
const PASSO_COERENTE_S = 300; /* entre duas amostras da quarentena, no máximo isto (o normal são 10 s) */
const AMOSTRA_S = 10; /* intervalo nominal das amostras: o peso de um balde fechado na média da célula */
const LIMITE_DE_PONTOS = 300;
const NUMERO_DE_METRICAS = 6; /* cpu, mem, disco, esc, rx, tx */
const CAMPOS_DO_PONTO = 9; /* t + 8 valores */
const CAMPOS_COM_PESOS = 15; /* + as 6 contagens de amostras */
const VALOR_MAXIMO = 1e13; /* qualquer coisa acima é lixo do /proc */

/* a ordem das métricas dentro de `soma` e `cont`: 0 cpu, 1 mem, 2 disco, 3 esc, 4 rx, 5 tx */
const FRACAO = [true, true, true, false, false, false];

const FAIXAS = [
  { id: '10s', passo: 10, janela: 3600 },
  { id: '1m', passo: 60, janela: 86400 },
  { id: '10m', passo: 600, janela: 604800 },
  { id: '1h', passo: 3600, janela: 2592000 }
];
FAIXAS.forEach(function (f) { f.capacidade = Math.ceil(f.janela / f.passo) + 2; });

/* janela pedida -> faixa de onde sai, passo da resposta (múltiplo do passo da faixa) e quantas células tem */
const JANELAS = {
  '10m': { segundos: 600, faixa: 0, passo: 10 },
  '1h': { segundos: 3600, faixa: 0, passo: 20 },
  '1d': { segundos: 86400, faixa: 1, passo: 300 },
  '7d': { segundos: 604800, faixa: 2, passo: 2400 },
  '30d': { segundos: 2592000, faixa: 3, passo: 10800 }
};
Object.keys(JANELAS).forEach(function (k) { JANELAS[k].celulas = JANELAS[k].segundos / JANELAS[k].passo; });

function janelaValida(codigo) {
  return typeof codigo === 'string' && Object.prototype.hasOwnProperty.call(JANELAS, codigo);
}

/* ---------- funções puras ---------- */

/* soma dos setores escritos nos discos INTEIROS de /proc/diskstats (sd*, vd*, xvd*, nvme*n*, mmcblk*; sem partições, loop,
   ram, dm e md, que contariam o mesmo byte duas vezes). Setor do diskstats é sempre 512 bytes. null se não há nenhum. */
const DISCO_INTEIRO = /^(sd[a-z]+|vd[a-z]+|xvd[a-z]+|hd[a-z]+|nvme\d+n\d+|mmcblk\d+)$/;
function lerSetoresEscritos(texto) {
  if (typeof texto !== 'string' || !texto) return null;
  let total = 0, achou = false;
  texto.split('\n').forEach(function (l) {
    let c = l.trim().split(/\s+/);
    if (c.length < 10 || !DISCO_INTEIRO.test(c[2])) return;
    let setores = Number(c[9]);
    if (!isFinite(setores) || setores < 0) return;
    total += setores;
    achou = true;
  });
  return achou ? total : null;
}

function numeroOuNulo(v, fracao) {
  if (typeof v !== 'number' || !isFinite(v) || v < 0 || v > VALOR_MAXIMO) return null;
  if (fracao && v > 1) return 1;
  return v;
}

function arredondar(v, casas) {
  if (v === null) return null;
  let f = casas === 4 ? 10000 : 1;
  return Math.round(v * f) / f;
}

function novoBalde(indice) {
  return { i: indice, s: [0, 0, 0, 0, 0, 0], c: [0, 0, 0, 0, 0, 0], m: [null, null] };
}

function acumular(balde, am) {
  /* am: { cpu, cpuMax, mem, disco, esc, escMax, rx, tx } já validado (número ou null) */
  let valores = [am.cpu, am.mem, am.disco, am.esc, am.rx, am.tx];
  for (let k = 0; k < NUMERO_DE_METRICAS; k++) {
    if (valores[k] !== null) { balde.s[k] += valores[k]; balde.c[k]++; }
  }
  let cmax = am.cpuMax !== null ? am.cpuMax : am.cpu;
  let emax = am.escMax !== null ? am.escMax : am.esc;
  if (cmax !== null && (balde.m[0] === null || cmax > balde.m[0])) balde.m[0] = cmax;
  if (emax !== null && (balde.m[1] === null || emax > balde.m[1])) balde.m[1] = emax;
}

function media(balde, k) {
  return balde.c[k] > 0 ? balde.s[k] / balde.c[k] : null;
}

/* o balde vira um ponto [t, cpu, cpuMax, mem, disco, esc, escMax, rx, tx]; null se não tem nenhum valor */
function baldeParaPonto(balde, passo) {
  let tem = false;
  for (let k = 0; k < NUMERO_DE_METRICAS; k++) if (balde.c[k] > 0) tem = true;
  if (!tem) return null;
  return [balde.i * passo,
    arredondar(media(balde, 0), 4), arredondar(balde.m[0], 4),
    arredondar(media(balde, 1), 4), arredondar(media(balde, 2), 4),
    arredondar(media(balde, 3), 0), arredondar(balde.m[1], 0),
    arredondar(media(balde, 4), 0), arredondar(media(balde, 5), 0),
    balde.c[0], balde.c[1], balde.c[2], balde.c[3], balde.c[4], balde.c[5]];
}

function pontoValido(p) {
  if (!Array.isArray(p) || (p.length !== CAMPOS_DO_PONTO && p.length !== CAMPOS_COM_PESOS)) return false;
  if (typeof p[0] !== 'number' || !isFinite(p[0]) || p[0] < 0 || Math.floor(p[0]) !== p[0]) return false;
  for (let i = 1; i < CAMPOS_DO_PONTO; i++) {
    if (p[i] !== null && (typeof p[i] !== 'number' || !isFinite(p[i]) || p[i] < 0 || p[i] > VALOR_MAXIMO)) return false;
  }
  for (let j = CAMPOS_DO_PONTO; j < p.length; j++) {
    if (typeof p[j] !== 'number' || !isFinite(p[j]) || p[j] < 0 || Math.floor(p[j]) !== p[j]) return false; /* contagem de amostras */
  }
  return true;
}

function baldeValido(b) {
  if (!b || typeof b !== 'object') return false;
  if (typeof b.i !== 'number' || !isFinite(b.i) || b.i < 0 || Math.floor(b.i) !== b.i) return false;
  if (!Array.isArray(b.s) || b.s.length !== NUMERO_DE_METRICAS || !Array.isArray(b.c) || b.c.length !== NUMERO_DE_METRICAS) return false;
  if (!Array.isArray(b.m) || b.m.length !== 2) return false;
  for (let k = 0; k < NUMERO_DE_METRICAS; k++) {
    if (typeof b.s[k] !== 'number' || !isFinite(b.s[k]) || b.s[k] < 0) return false;
    if (typeof b.c[k] !== 'number' || !isFinite(b.c[k]) || b.c[k] < 0 || Math.floor(b.c[k]) !== b.c[k]) return false;
  }
  for (let j = 0; j < 2; j++) {
    if (b.m[j] !== null && (typeof b.m[j] !== 'number' || !isFinite(b.m[j]) || b.m[j] < 0)) return false;
  }
  return true;
}

/* ---------- o gravador ---------- */

/*
  opcoes:
    arquivo   caminho do JSON (sem ele o gravador só vive em memória)
    relogio   () => milissegundos (padrão Date.now; os testes injetam o deles)
    limite    teto de bytes ao gravar antes de enxugar as faixas (padrão 2 MiB; os testes baixam)
    avisar    (texto) => void para o que merece uma linha no log (padrão console.error)
*/
function criar(opcoes) {
  opcoes = opcoes || {};
  let arquivo = opcoes.arquivo || null;
  let relogio = opcoes.relogio || Date.now;
  let limitePodar = opcoes.limite || LIMITE_PARA_PODAR;
  let avisar = opcoes.avisar || function (t) { console.error('[historico] ' + t); };

  let faixas = FAIXAS.map(function () { return { pontos: [], aberto: null }; });
  let ultimoT = 0;
  let sujo = false;
  let ultimoErroDeDisco = null;
  let quarentena = null; /* { desde, ultimo, n, paraTras } enquanto o relógio saltou e ainda não se sabe qual lado está certo */
  let ultimaAmostraBoa = null;
  let estatisticas = { amostras: 0, ignoradas: 0, descartadasPeloRelogio: 0, emQuarentena: 0, gravacoes: 0, falhasDeGravacao: 0 };

  function agoraS() { return Math.floor(relogio() / 1000); }

  function validarAmostra(a) {
    a = a || {};
    return {
      cpu: numeroOuNulo(a.cpu, true), cpuMax: numeroOuNulo(a.cpuMax, true),
      mem: numeroOuNulo(a.mem, true), disco: numeroOuNulo(a.disco, true),
      esc: numeroOuNulo(a.esc, false), escMax: numeroOuNulo(a.escMax, false),
      rx: numeroOuNulo(a.rx, false), tx: numeroOuNulo(a.tx, false)
    };
  }

  /* só pela capacidade da faixa: NUNCA pela idade (uma amostra com a hora errada à frente levaria o histórico bom embora). O que passa
     da janela não aparece na consulta mesmo, e vai saindo pela capacidade conforme as amostras novas chegam. */
  function podarFaixa(i) {
    let f = faixas[i], def = FAIXAS[i];
    while (f.pontos.length > def.capacidade) f.pontos.shift();
  }

  function fecharBalde(i) {
    let f = faixas[i];
    let p = baldeParaPonto(f.aberto, FAIXAS[i].passo);
    if (p) f.pontos.push(p);
    f.aberto = null;
  }

  /* o relógio voltou mais de 1 hora: o que está depois de `t` foi gravado sob um relógio errado */
  function descartarFuturo(t) {
    faixas.forEach(function (f, i) {
      let passo = FAIXAS[i].passo;
      f.pontos = f.pontos.filter(function (p) { return p[0] <= t; });
      if (f.aberto && f.aberto.i * passo > t) f.aberto = null;
    });
    estatisticas.descartadasPeloRelogio++;
  }

  /* O relógio saltou: decide se esta amostra pode entrar. Devolve true quando a quarentena acabou e a amostra vale. */
  function aceitarSalto(t, paraTras) {
    let coerente = quarentena && quarentena.paraTras === paraTras && t >= quarentena.ultimo && t - quarentena.ultimo <= PASSO_COERENTE_S;
    if (!coerente) quarentena = { desde: t, ultimo: t, n: 0, paraTras: paraTras };
    quarentena.ultimo = t;
    quarentena.n++;
    let aceito = paraTras ? (t - quarentena.desde >= QUARENTENA_DE_RECUO_S && quarentena.n >= AMOSTRAS_PARA_ACEITAR_SALTO)
      : quarentena.n >= AMOSTRAS_PARA_ACEITAR_SALTO;
    if (!aceito) return false;
    quarentena = null;
    if (paraTras) descartarFuturo(t);
    return true;
  }

  /* devolve true se a amostra entrou */
  function registrar(amostra) {
    let t = agoraS();
    if (ultimoT > 0) {
      let desvio = t - ultimoT;
      if (desvio < 0 && -desvio < RECUO_TOLERADO_S) { estatisticas.ignoradas++; quarentena = null; return false; }
      if (desvio < 0 || desvio > SALTO_PARA_FRENTE_S) {
        if (!aceitarSalto(t, desvio < 0)) { estatisticas.emQuarentena++; return false; }
      } else {
        quarentena = null; /* a hora voltou ao normal: o salto era passageiro e o histórico está intacto */
      }
    }
    let am = validarAmostra(amostra);
    FAIXAS.forEach(function (def, i) {
      let f = faixas[i];
      let indice = Math.floor(t / def.passo);
      if (f.aberto && f.aberto.i !== indice) fecharBalde(i);
      if (!f.aberto) f.aberto = novoBalde(indice);
      acumular(f.aberto, am);
      podarFaixa(i);
    });
    ultimoT = t;
    ultimaAmostraBoa = { t: t, am: am };
    sujo = true;
    estatisticas.amostras++;
    return true;
  }

  /* ---- consulta ---- */
  /* cada ponto com o PESO de cada métrica na média da célula: o número de amostras que de fato entraram no balde (um balde com poucas
     amostras não vale o mesmo que um cheio, aberto ou fechado). Só um ponto antigo, gravado sem as contagens, pesa o nominal (passo / 10 s). */
  function pontosDaFaixa(i) {
    let f = faixas[i], def = FAIXAS[i];
    let nominal = def.passo / AMOSTRA_S;
    let todos = f.pontos.map(function (p) {
      let w = p.length === CAMPOS_COM_PESOS ? p.slice(CAMPOS_DO_PONTO) : [nominal, nominal, nominal, nominal, nominal, nominal];
      return { p: p, w: w };
    });
    if (f.aberto) {
      let p = baldeParaPonto(f.aberto, def.passo);
      if (p) todos.push({ p: p, w: f.aberto.c.slice() });
    }
    return todos;
  }

  function consultar(codigo, agoraMs) {
    if (!janelaValida(codigo)) throw new Error('janela inválida');
    let j = JANELAS[codigo];
    let agora = typeof agoraMs === 'number' ? Math.floor(agoraMs / 1000) : agoraS();
    let fim = Math.floor(agora / j.passo);
    let inicio = fim - j.celulas + 1;
    let n = j.celulas;
    let res = {
      cpu: [], cpu_max: [], mem: [], disco_uso: [], disco_escrita_bps: [], disco_escrita_max_bps: [], rx_bps: [], tx_bps: []
    };
    /* acumuladores por célula: somas e contagens das médias, máximos dos máximos */
    let soma = [], cont = [], max = [];
    for (let c = 0; c < n; c++) { soma.push([0, 0, 0, 0, 0, 0]); cont.push([0, 0, 0, 0, 0, 0]); max.push([null, null]); }
    pontosDaFaixa(j.faixa).forEach(function (pw) {
      let p = pw.p;
      let celula = Math.floor(p[0] / j.passo) - inicio;
      if (celula < 0 || celula >= n) return;
      let medias = [p[1], p[3], p[4], p[5], p[7], p[8]];
      for (let k = 0; k < NUMERO_DE_METRICAS; k++) {
        if (medias[k] !== null && pw.w[k] > 0) { soma[celula][k] += medias[k] * pw.w[k]; cont[celula][k] += pw.w[k]; }
      }
      if (p[2] !== null && (max[celula][0] === null || p[2] > max[celula][0])) max[celula][0] = p[2];
      if (p[6] !== null && (max[celula][1] === null || p[6] > max[celula][1])) max[celula][1] = p[6];
    });
    function mediaDaCelula(c, k) {
      if (cont[c][k] === 0) return null;
      let v = soma[c][k] / cont[c][k];
      return FRACAO[k] ? Math.round(v * 10000) / 10000 : Math.round(v);
    }
    for (let d = 0; d < n; d++) {
      res.cpu.push(mediaDaCelula(d, 0));
      res.cpu_max.push(max[d][0] === null ? null : Math.round(max[d][0] * 10000) / 10000);
      res.mem.push(mediaDaCelula(d, 1));
      res.disco_uso.push(mediaDaCelula(d, 2));
      res.disco_escrita_bps.push(mediaDaCelula(d, 3));
      res.disco_escrita_max_bps.push(max[d][1] === null ? null : Math.round(max[d][1]));
      res.rx_bps.push(mediaDaCelula(d, 4));
      res.tx_bps.push(mediaDaCelula(d, 5));
    }
    /* o ÚLTIMO valor real gravado (não a média da última célula): é o "agora" dos gráficos, igual aos indicadores da tela */
    let agoraReal = null;
    if (ultimaAmostraBoa) {
      let u = ultimaAmostraBoa.am;
      agoraReal = {
        t: new Date(ultimaAmostraBoa.t * 1000).toISOString(),
        cpu: arredondar(u.cpu, 4), mem: arredondar(u.mem, 4), disco_uso: arredondar(u.disco, 4),
        disco_escrita_bps: arredondar(u.esc, 0), rx_bps: arredondar(u.rx, 0), tx_bps: arredondar(u.tx, 0)
      };
    }
    return Object.assign({
      janela: codigo,
      agora: agoraReal,
      passo_s: j.passo,
      inicio: new Date(inicio * j.passo * 1000).toISOString(),
      fim: new Date((fim + 1) * j.passo * 1000).toISOString(),
      quando: new Date(agora * 1000).toISOString()
    }, res);
  }

  /* ---- disco ---- */
  function serializar() {
    let f = {};
    FAIXAS.forEach(function (def, i) {
      let fx = faixas[i];
      let obj = { p: fx.pontos };
      if (fx.aberto) obj.a = fx.aberto;
      f[def.id] = obj;
    });
    return JSON.stringify({ v: VERSAO_ARQUIVO, u: ultimoT, f: f });
  }

  function enxugar() {
    /* só se o arquivo passou do teto: descarta a metade mais antiga de cada faixa */
    faixas.forEach(function (fx) { fx.pontos = fx.pontos.slice(Math.floor(fx.pontos.length / 2)); });
  }

  function salvar() {
    if (!arquivo) return false;
    let texto = serializar();
    let voltas = 0;
    while (Buffer.byteLength(texto) > limitePodar && voltas < 16) { enxugar(); texto = serializar(); voltas++; }
    let tmp = arquivo + '.tmp-' + process.pid;
    try {
      fs.mkdirSync(path.dirname(arquivo), { recursive: true });
      let fd = fs.openSync(tmp, 'w', 0o600);
      try { fs.writeSync(fd, texto); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      fs.renameSync(tmp, arquivo);
      sujo = false;
      estatisticas.gravacoes++;
      if (ultimoErroDeDisco) { avisar('voltou a gravar ' + arquivo); ultimoErroDeDisco = null; }
      return true;
    } catch (e) {
      try { fs.unlinkSync(tmp); } catch (e2) { /* não chegou a existir */ }
      estatisticas.falhasDeGravacao++;
      let motivo = e && e.code ? e.code : String(e && e.message || e);
      if (ultimoErroDeDisco !== motivo) { avisar('não consegui gravar ' + arquivo + ' (' + motivo + '); sigo só em memória'); ultimoErroDeDisco = motivo; }
      return false;
    }
  }

  function guardarCorrompido(motivo) {
    try { fs.renameSync(arquivo, arquivo + '.corrompido'); } catch (e) { /* sem permissão: o próximo salvar substitui o arquivo mesmo assim */ }
    avisar('arquivo de histórico descartado (' + motivo + '); começando vazio');
  }

  function carregar() {
    if (!arquivo) return false;
    let texto;
    try {
      let st = fs.statSync(arquivo);
      if (!st.isFile()) return false;
      if (st.size > LIMITE_DO_ARQUIVO) { guardarCorrompido('grande demais: ' + st.size + ' bytes'); return false; }
      texto = fs.readFileSync(arquivo, 'utf8');
    } catch (e) {
      return false; /* não existe ainda (o normal na primeira vez) ou não dá para ler: começa vazio */
    }
    let obj;
    try { obj = JSON.parse(texto); } catch (e) { guardarCorrompido('JSON inválido'); return false; }
    if (!obj || typeof obj !== 'object' || obj.v !== VERSAO_ARQUIVO || !obj.f || typeof obj.f !== 'object') {
      guardarCorrompido('formato desconhecido');
      return false;
    }
    let carregadas = 0;
    FAIXAS.forEach(function (def, i) {
      let fx = obj.f[def.id];
      if (!fx || !Array.isArray(fx.p)) return;
      let ok = true, anterior = -1;
      for (let n = 0; n < fx.p.length; n++) {
        let p = fx.p[n];
        if (!pontoValido(p) || p[0] <= anterior || p[0] % def.passo !== 0) { ok = false; break; }
        anterior = p[0];
      }
      if (!ok) { avisar('a faixa ' + def.id + ' do histórico está estragada; começando só ela vazia'); return; }
      faixas[i].pontos = fx.p.slice(-def.capacidade);
      if (fx.a !== undefined && baldeValido(fx.a) && fx.a.i * def.passo > anterior) {
        faixas[i].aberto = { i: fx.a.i, s: fx.a.s.slice(), c: fx.a.c.slice(), m: fx.a.m.slice() };
      }
      carregadas += faixas[i].pontos.length;
    });
    if (typeof obj.u === 'number' && isFinite(obj.u) && obj.u >= 0) ultimoT = Math.floor(obj.u);
    return carregadas > 0;
  }

  return {
    registrar: registrar,
    consultar: consultar,
    salvar: salvar,
    carregar: carregar,
    suja: function () { return sujo; },
    estatisticas: function () { return Object.assign({}, estatisticas); },
    /* só para os testes */
    _faixas: function () { return faixas; },
    _serializar: serializar
  };
}

module.exports = {
  criar: criar,
  janelaValida: janelaValida,
  lerSetoresEscritos: lerSetoresEscritos,
  JANELAS: JANELAS,
  FAIXAS: FAIXAS,
  LIMITE_DE_PONTOS: LIMITE_DE_PONTOS,
  RECUO_TOLERADO_S: RECUO_TOLERADO_S,
  SALTO_PARA_FRENTE_S: SALTO_PARA_FRENTE_S,
  AMOSTRAS_PARA_ACEITAR_SALTO: AMOSTRAS_PARA_ACEITAR_SALTO,
  QUARENTENA_DE_RECUO_S: QUARENTENA_DE_RECUO_S
};
