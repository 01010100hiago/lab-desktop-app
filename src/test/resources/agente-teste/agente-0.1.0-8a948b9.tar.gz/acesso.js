// Arquivo SINTETICO de teste: este NAO e o agente (agente-painel). Existe so para os testes do instalador.
